import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Troca cada "System.gc()" do jogo por "Res.gc()" (no-op). No J2ME o jogo chamava o coletor na mao ao
 * carregar fases/imagens; no Android cada System.gc() BLOQUEIA a thread do jogo numa coleta completa
 * (dezenas de ms) e causa os travamentos. O ART coleta sozinho, em segundo plano.
 * Uso (JDK 21): java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
 *      --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED tools/PatchGc.java entrada.jar saida.jar
 */
public class PatchGc {
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        Enumeration<? extends ZipEntry> en = in.entries();
        int patched = 0;
        while (en.hasMoreElements()) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().endsWith(".class")) {
                ClassNode cn = new ClassNode();
                new ClassReader(data).accept(cn, 0);
                int n = 0;
                for (MethodNode m : cn.methods) {
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        if (i.getOpcode() != Opcodes.INVOKESTATIC) continue;
                        MethodInsnNode mi = (MethodInsnNode) i;
                        if (mi.owner.equals("java/lang/System") && mi.name.equals("gc") && mi.desc.equals("()V")) {
                            mi.owner = "com/sod/port/Res";
                            n++;
                        }
                    }
                }
                if (n > 0) {
                    ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
                    cn.accept(cw);
                    data = cw.toByteArray();
                    patched += n;
                    System.out.println(ze.getName() + ": " + n + " chamada(s) de System.gc() trocadas");
                }
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        in.close();
        System.out.println("total: " + patched);
    }
}
