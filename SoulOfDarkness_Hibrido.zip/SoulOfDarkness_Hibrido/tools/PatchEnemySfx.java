import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Som de ATAQUE dos inimigos. Cada inimigo e uma entidade 'b' cujo tipo (b.ao) o despachante b.t() liga a um metodo de IA
 * (tipo 1 zombie -> bu(), 11 werewolf -> bF(), 15 fish -> cf(), 83 dragon -> bR(), 99 girl -> aP(), 8 bigeye -> bB() ...;
 * tipo -> sprite via b.bs[] e nomes do res.bar do DSi). Dentro desses metodos, cada spawn b.a(IIIIIIZ)Lb; com tipo 300/302/303/308
 * (objeto de ataque/impacto) ganha SfxHook.enemy(<tipo do inimigo>) antes da chamada.
 * Uso: java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED tools/PatchEnemySfx.java entrada.jar saida.jar
 */
public class PatchEnemySfx {
    // metodo de IA (b.<nome>()V) -> tipo de entidade
    static final Map<String, Integer> AI = new LinkedHashMap<>();
    static {
        AI.put("bu", 1);    // zombie
        AI.put("br", 2); AI.put("bt", 3);   // imp
        AI.put("bz", 4);    // ghost
        AI.put("bA", 5);    // shadow_hand
        AI.put("bB", 8);    // bigeye
        AI.put("bC", 9);    // bighand
        AI.put("bE", 10);   // laser_bat
        AI.put("bF", 11);   // werewolf
        AI.put("bH", 13);   // poison_ball
        AI.put("bJ", 14);   // waterelement
        AI.put("cf", 15);   // fish
        AI.put("bR", 83);   // dragon
        AI.put("aP", 99);   // girl
        AI.put("bO", 90); AI.put("bQ", 100);  // boss_03
    }
    static AbstractInsnNode prevReal(AbstractInsnNode n) {
        AbstractInsnNode p = n.getPrevious();
        while (p != null && p.getOpcode() < 0) p = p.getPrevious();
        return p;
    }
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        Map<String, Integer> done = new LinkedHashMap<>();
        for (Enumeration<? extends ZipEntry> en = in.entries(); en.hasMoreElements();) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().equals("b.class")) {
                ClassNode cn = new ClassNode();
                new ClassReader(data).accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    if (!m.desc.equals("()V") || (m.access & Opcodes.ACC_STATIC) != 0) continue;
                    Integer type = AI.get(m.name);
                    if (type == null) continue;
                    List<AbstractInsnNode> sites = new ArrayList<>();
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        if (i.getOpcode() != Opcodes.INVOKEVIRTUAL) continue;
                        MethodInsnNode mi = (MethodInsnNode) i;
                        if (!(mi.owner.equals("b") && mi.name.equals("a") && mi.desc.equals("(IIIIIIZ)Lb;"))) continue;
                        AbstractInsnNode p = i;
                        for (int k = 0; k < 14 && p != null; k++) {
                            p = prevReal(p);
                            if (p instanceof IntInsnNode && p.getOpcode() == Opcodes.SIPUSH) {
                                int v = ((IntInsnNode) p).operand;
                                if (v == 300 || v == 302 || v == 303 || v == 308) { sites.add(i); break; }
                            }
                        }
                    }
                    for (AbstractInsnNode s : sites) {
                        InsnList l = new InsnList();
                        l.add(new IntInsnNode(Opcodes.BIPUSH, type));
                        l.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/sod/port/SfxHook", "enemy", "(I)V", false));
                        m.instructions.insertBefore(s, l);
                    }
                    done.merge(m.name + "(tipo " + type + ")", sites.size(), Integer::sum);
                }
                ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
                cn.accept(cw);
                data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        in.close();
        System.out.println("ganchos de ataque inseridos: " + done);
    }
}
