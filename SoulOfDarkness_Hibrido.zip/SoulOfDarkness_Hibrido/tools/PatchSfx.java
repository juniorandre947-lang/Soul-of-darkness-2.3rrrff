import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Insere chamadas SfxHook.play(id) em b.class (efeitos sonoros do Kale vindos da versao DSi):
 *   0 pulo   : aZ(), depois de "putfield b.H" com -2560 ou -3328 (impulso do pulo)
 *   1 ataque : aZ(), antes de b.a(IIIIIIZ)Lb; quando o tipo criado e 300/302/303
 *   2 dano   : d(I)Z, antes de "putstatic e.q" (vida)
 *   3 morte  : aZ(), antes de b.b(I)V quando o estado e 12
 * Uso: PatchSfx entrada.jar saida.jar   (JDK 21: --add-exports java.base/jdk.internal.org.objectweb.asm{,.tree}=ALL-UNNAMED)
 */
public class PatchSfx {
    static InsnList call(int id) {
        InsnList l = new InsnList();
        l.add(new IntInsnNode(Opcodes.BIPUSH, id));
        l.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/sod/port/SfxHook", "play", "(I)V", false));
        return l;
    }
    static AbstractInsnNode prevReal(AbstractInsnNode i) {
        AbstractInsnNode p = i.getPrevious();
        while (p != null && p.getOpcode() < 0) p = p.getPrevious();
        return p;
    }
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        int jump = 0, atk = 0, hurt = 0, dead = 0;
        for (Enumeration<? extends ZipEntry> en = in.entries(); en.hasMoreElements();) {
            ZipEntry ze = en.nextElement();
            byte[] data = in.getInputStream(ze).readAllBytes();
            if (ze.getName().equals("b.class")) {
                ClassNode cn = new ClassNode();
                new ClassReader(data).accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    boolean aZ = m.name.equals("aZ") && m.desc.equals("()V");
                    boolean dmg = m.name.equals("d") && m.desc.equals("(I)Z");
                    if (!aZ && !dmg) continue;
                    List<Runnable> work = new ArrayList<>();
                    for (AbstractInsnNode i = m.instructions.getFirst(); i != null; i = i.getNext()) {
                        final AbstractInsnNode ins = i;
                        if (aZ && i.getOpcode() == Opcodes.PUTFIELD) {
                            FieldInsnNode f = (FieldInsnNode) i;
                            AbstractInsnNode p = prevReal(i);
                            if (f.owner.equals("b") && f.name.equals("H") && p instanceof IntInsnNode) {
                                int v = ((IntInsnNode) p).operand;
                                if (v == -2560 || v == -3328) { work.add(() -> m.instructions.insert(ins, call(0))); jump++; }
                            }
                        }
                        if (aZ && i.getOpcode() == Opcodes.INVOKEVIRTUAL) {
                            MethodInsnNode mi = (MethodInsnNode) i;
                            if (mi.owner.equals("b") && mi.name.equals("a") && mi.desc.equals("(IIIIIIZ)Lb;")) {
                                boolean ok = false; AbstractInsnNode p = i;
                                for (int k = 0; k < 14 && p != null; k++) {
                                    p = prevReal(p == null ? i : p);
                                    if (p == null) break;
                                    if (p instanceof IntInsnNode && p.getOpcode() == Opcodes.SIPUSH) {
                                        int v = ((IntInsnNode) p).operand;
                                        if (v == 300 || v == 302 || v == 303) { ok = true; break; }
                                    }
                                }
                                if (ok) { work.add(() -> m.instructions.insertBefore(ins, call(1))); atk++; }
                            }
                            if (mi.owner.equals("b") && mi.name.equals("b") && mi.desc.equals("(I)V")) {
                                AbstractInsnNode p = prevReal(i);
                                if (p instanceof IntInsnNode && ((IntInsnNode) p).operand == 12) { work.add(() -> m.instructions.insertBefore(ins, call(3))); dead++; }
                            }
                        }
                        if (dmg && i.getOpcode() == Opcodes.PUTSTATIC) {
                            FieldInsnNode f = (FieldInsnNode) i;
                            if (f.owner.equals("e") && f.name.equals("q")) { work.add(() -> m.instructions.insertBefore(ins, call(2))); hurt++; break; }
                        }
                    }
                    for (Runnable r : work) r.run();
                }
                ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
                cn.accept(cw);
                data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(ze.getName());
            ne.setTime(ze.getTime());
            out.putNextEntry(ne);
            out.write(data);
            out.closeEntry();
        }
        out.close();
        System.out.println("pulo=" + jump + " ataque=" + atk + " dano=" + hurt + " morte=" + dead);
    }
}
