public final class e {
    public static int dg, dh, di, dl, df, dk, dm, dj, T, U;
    public static b bL, first;
    private static void ak() { if (bL != null) bL.t(); }   // heroi 1 (como o e.ak() do jogo)
    private static void ao() { }
}
