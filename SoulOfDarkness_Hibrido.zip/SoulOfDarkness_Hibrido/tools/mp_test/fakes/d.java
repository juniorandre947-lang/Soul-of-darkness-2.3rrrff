public final class d { public d() { } }
