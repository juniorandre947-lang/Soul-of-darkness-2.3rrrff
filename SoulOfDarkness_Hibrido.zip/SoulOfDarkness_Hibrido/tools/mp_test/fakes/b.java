public final class b {
    public static boolean bQ;
    public int K = 100, L = 100, a = 100 << 8, b = 0, G = 0, H = 0, f = 0;
    public int[] j = new int[4], k = new int[4];
    public static volatile int h1SawGuest, h2SawHost, h2SawGuest, h1SawHost;
    public b() { }
    public void t() {                                   // chamado por reflexao (privado como no jogo? aqui so precisa existir)
        int all = e.df | e.di | e.dh;
        if (this == e.first) { if ((all & 65536) != 0) h1SawGuest++; if ((all & 16384) != 0) h1SawHost++; }
        else { if ((all & 16384) != 0) h2SawHost++; if ((all & 65536) != 0) h2SawGuest++;
               for (int i = 0; i < 3000; i++) Thread.onSpinWait(); }     // alarga a janela em que as teclas do convidado estao nos estaticos
    }
    public void v() { }
    public void tt() { t(); }
}
