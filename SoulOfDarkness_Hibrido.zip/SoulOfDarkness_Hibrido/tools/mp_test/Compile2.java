import javax.tools.*; import java.util.*;
public class Compile2 { public static void main(String[] a) { JavaCompiler c = ToolProvider.getSystemJavaCompiler();
  System.out.println("rc=" + c.run(null,null,null,a)); } }
