import java.lang.reflect.*;
public class Race {
    public static void main(String[] a) throws Exception {
        final boolean useLock = a[0].equals("lock");
        Class<?> net = Class.forName("com.sod.port.Net"), hook = Class.forName("com.sod.port.Hook");
        net.getField("role").setInt(null, 1);                                  // HOST
        Field c = net.getDeclaredField("connected"); c.setAccessible(true); c.setBoolean(null, true);
        Field rb = net.getDeclaredField("remoteBits"); rb.setAccessible(true); rb.setInt(null, 65536);   // convidado segura OK
        e.first = new b(); Method set = hook.getMethod("setHero", Object.class); set.invoke(null, e.first);
        Object lk; try { lk = hook.getField("INPUT_LOCK").get(null); } catch (NoSuchFieldException ex) { lk = new Object(); }
        final Object lock = lk;
        final boolean[] stop = { false };
        Thread ui = new Thread(() -> {                                         // thread da interface: teclas do ANFITRIAO (16384)
            while (!stop[0]) {
                if (useLock) synchronized (lock) { press(); } else press();
                for (int i = 0; i < 400; i++) Thread.onSpinWait();
                if (useLock) synchronized (lock) { release(); } else release();
                for (int i = 0; i < 400; i++) Thread.onSpinWait();
            }
        });
        ui.start();
        Method ak = hook.getMethod("ak");
        for (int i = 0; i < 20000; i++) ak.invoke(null);
        stop[0] = true; ui.join();
        System.out.println("heroi1 viu tecla do CONVIDADO : " + b.h1SawGuest);
        System.out.println("heroi2 viu tecla do ANFITRIAO : " + b.h2SawHost);
        System.out.println("(controle) heroi1 viu o anfitriao: " + b.h1SawHost);
    }
    static void press() {                                                      // e.keyPressed (leitura-modificacao-escrita, como no jogo)
        int cur = e.di; Thread.onSpinWait(); e.di = cur | 16384;
        int d2 = e.dh; e.dh = d2 | 16384;
        e.dg = 16384;
    }
    static void release() { e.di &= ~16384; e.dh &= ~16384; e.dg = 0; }
}
