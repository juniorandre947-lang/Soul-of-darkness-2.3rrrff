import java.io.*; import java.net.*;
import com.sod.port.Net;
public class NetTest {
    public static void main(String[] a) throws Exception {
        Net.startHost(new Net.Source() { public byte[] grabJpeg() { return new byte[]{1,2,3}; } public void refresh() { } });
        Thread.sleep(300);
        Socket s = new Socket("127.0.0.1", Net.PORT);
        DataOutputStream o = new DataOutputStream(s.getOutputStream());
        Thread.sleep(300);
        System.out.println("conectado: " + Net.connected());
        // toque curto: down+up quase juntos (menos que um quadro)
        o.writeByte(1); o.writeShort(-4); o.writeBoolean(true); o.writeByte(1); o.writeShort(-4); o.writeBoolean(false); o.flush();
        Thread.sleep(200);
        System.out.println("remoteBits apos toque curto = " + Net.remoteBits() + " (esperado 0)");
        System.out.println("takeTaps = " + Net.takeTaps() + " (esperado 8192)  | segunda leitura = " + Net.takeTaps() + " (esperado 0)");
        // segura 'direita' e fica mandando ping por 8 s (> timeout de 6 s): tem que continuar conectado
        o.writeByte(1); o.writeShort(-4); o.writeBoolean(true); o.flush();
        for (int i = 0; i < 8; i++) { Thread.sleep(1000); o.writeByte(2); o.flush(); }
        System.out.println("apos 8 s com ping: conectado=" + Net.connected() + " bits=" + Net.remoteBits() + " (esperado true / 8192)");
        // para de falar (conexao fantasma, sem FIN): em ~6 s o anfitriao tem que soltar tudo
        long t0 = System.currentTimeMillis();
        while (Net.connected() && System.currentTimeMillis() - t0 < 10000) Thread.sleep(100);
        System.out.println("conexao fantasma derrubada em " + (System.currentTimeMillis() - t0) + " ms; conectado=" + Net.connected() + " bits=" + Net.remoteBits() + " (esperado false / 0)");
        // novo convidado consegue entrar
        Socket s2 = new Socket("127.0.0.1", Net.PORT); Thread.sleep(500);
        System.out.println("novo convidado entrou: " + Net.connected());
        System.exit(0);
    }
}
