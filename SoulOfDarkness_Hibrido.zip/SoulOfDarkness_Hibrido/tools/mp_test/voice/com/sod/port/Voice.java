package com.sod.port;
public final class Voice {
    public static volatile int starts, stops; public static final java.util.concurrent.LinkedBlockingQueue<byte[]> got = new java.util.concurrent.LinkedBlockingQueue<byte[]>();
    static void start() { starts++; } static void stop() { stops++; } static void onRemote(byte[] b) { got.offer(b); }
}
