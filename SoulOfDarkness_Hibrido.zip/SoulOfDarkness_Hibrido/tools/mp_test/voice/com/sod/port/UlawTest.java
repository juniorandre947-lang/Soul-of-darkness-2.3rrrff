package com.sod.port;
public class UlawTest { public static void main(String[] a) {
  double sig=0, err=0; int worst=0;
  for (int i=0;i<16000;i++) { short x=(short)(12000*Math.sin(i*0.07)+3000*Math.sin(i*0.31)); short y=Ulaw.decode(Ulaw.encode(x));
    sig+=(double)x*x; err+=(double)(x-y)*(x-y); worst=Math.max(worst,Math.abs(x-y)); }
  System.out.printf("mu-law: SNR = %.1f dB (esperado > 30), maior erro = %d%n", 10*Math.log10(sig/err), worst);
  System.out.println("silencio -> " + Ulaw.decode(Ulaw.encode((short)0)) + ", +32767 -> " + Ulaw.decode(Ulaw.encode((short)32767)) + ", -32768 -> " + Ulaw.decode(Ulaw.encode((short)-32768)));
}}
