import java.io.*; import java.net.*; import com.sod.port.*;
public class NetVoiceTest { public static void main(String[] a) throws Exception {
  Net.startHost(new Net.Source() { public byte[] grabJpeg() { return new byte[]{9,9,9,9}; } public void refresh() { } });
  Thread.sleep(300);
  Socket s = new Socket("127.0.0.1", Net.PORT); s.setTcpNoDelay(true);
  DataOutputStream o = new DataOutputStream(s.getOutputStream()); DataInputStream in = new DataInputStream(s.getInputStream());
  Thread.sleep(300);
  // 1) convidado -> anfitriao: voz (160 bytes) e tecla, intercalados
  byte[] v = new byte[160]; for (int i=0;i<160;i++) v[i]=(byte)i;
  o.writeByte(3); o.writeShort(160); o.write(v); o.writeByte(1); o.writeShort(-4); o.writeBoolean(true); o.writeByte(3); o.writeShort(160); o.write(v); o.flush();
  Thread.sleep(300);
  System.out.println("anfitriao recebeu pacotes de voz: " + com.sod.port.Voice.got.size() + " (esperado 2); conteudo igual: " + java.util.Arrays.equals(com.sod.port.Voice.got.peek(), v) + "; tecla direita nao se perdeu: bits=" + Net.remoteBits() + " (esperado 8192); conectado=" + Net.connected());
  // 2) anfitriao -> convidado: voz enfileirada + imagens chegando ao mesmo tempo
  for (int i=0;i<30;i++) { byte[] p = new byte[160]; java.util.Arrays.fill(p,(byte)(i+1)); Net.sendVoice(p); Thread.sleep(20); }
  int frames=0, voices=0, bad=0; long t0=System.currentTimeMillis(); s.setSoTimeout(500);
  try { while (System.currentTimeMillis()-t0 < 1500) {
    int t = in.readUnsignedByte();
    if (t==1) { int n=in.readInt(); byte[] b=new byte[n]; in.readFully(b); frames++; if (n!=4) bad++; }
    else if (t==3) { int n=in.readUnsignedShort(); byte[] b=new byte[n]; in.readFully(b); voices++; if (n!=160) bad++; }
    else { bad++; break; } } } catch (SocketTimeoutException e) { }
  System.out.println("convidado recebeu imagens=" + frames + " (>0), pacotes de voz=" + voices + " (esperado 30), mensagens corrompidas=" + bad + " (esperado 0)");
  // 3) pacote de voz absurdo derruba a conexao (protecao)
  o.writeByte(3); o.writeShort(60000); o.flush(); Thread.sleep(500);
  System.out.println("apos pacote de voz invalido: conectado=" + Net.connected() + " (esperado false); Voice.start/stop = " + com.sod.port.Voice.starts + "/" + com.sod.port.Voice.stops + " (esperado 1/1)");
  System.exit(0);
}}
