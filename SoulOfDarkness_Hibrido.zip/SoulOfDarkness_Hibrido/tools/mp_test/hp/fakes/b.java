public final class b {
    public static boolean bQ; public static int bO, eP = 10;
    public int K = 100, L = 100, a = 100 << 8, b = 0, G = 0, H = 0, f = 0, h = 0;
    public int[] j = new int[4], k = new int[4];
    public static int h2Calls;
    public b() { }
    public boolean e() { return f == 12 && h >= 5; }
    public void b(int s) { f = s; h = 0; }
    public void t() {
        if (this == e.first) return;                       // heroi 1 nao faz nada
        h2Calls++;
        if (f == 12) { if (e()) e.a(12); h++; return; }    // como o jogo: ao fim da animacao chama e.a(12)
        e.q -= 10; bO = 5;                                 // heroi 2 toma 10 de dano por quadro
        if (e.q <= 0) { e.q = 0; b(12); }
    }
    public void v() { }
}
