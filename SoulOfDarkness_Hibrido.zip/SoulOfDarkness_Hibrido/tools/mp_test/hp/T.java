import java.lang.reflect.*;
public class T {
    public static void main(String[] x) throws Exception {
        Class<?> net = Class.forName("com.sod.port.Net"), hook = Class.forName("com.sod.port.Hook");
        net.getField("role").setInt(null, 1);
        Field c = net.getDeclaredField("connected"); c.setAccessible(true); c.setBoolean(null, true);
        e.first = new b(); hook.getMethod("setHero", Object.class).invoke(null, e.first);
        Method ak = hook.getMethod("ak");
        Field hp2 = hook.getDeclaredField("hp2"); hp2.setAccessible(true);
        Field fdead = hook.getDeclaredField("dead2"); fdead.setAccessible(true);
        ak.invoke(null);                                            // cria o heroi 2
        System.out.println("inicio: vida P1=" + e.q + " vida P2=" + hp2.getInt(null));
        int deadAt = -1, callsAtDeath = 0, respawnAt = -1;
        for (int i = 1; i <= 140; i++) {
            ak.invoke(null);
            if (deadAt < 0 && fdead.getBoolean(null)) { deadAt = i; }
            if (deadAt > 0 && respawnAt < 0 && !fdead.getBoolean(null)) { respawnAt = i; }
            if (i == 3) System.out.println("quadro 3: P1=" + e.q + " (esperado 60) P2=" + hp2.getInt(null) + " (esperado 30)");
        }
        System.out.println("P1 no fim = " + e.q + " (esperado 60: nunca perdeu vida)");
        System.out.println("game over disparado pelo heroi 2: " + e.gameOver + " vezes (esperado 0)");
        System.out.println("morreu no quadro " + deadAt + ", renasceu no quadro " + respawnAt + " (esperado ~+100)");
        System.out.println("P2 apos renascer: vida=" + hp2.getInt(null) + " (esperado ~30 antes de novo dano)");
    }
}
