import java.lang.reflect.*;
public class T {
    static b h2() throws Exception { Field f = Class.forName("com.sod.port.Hook").getDeclaredField("hero2"); f.setAccessible(true); return (b) f.get(null); }
    public static void main(String[] x) throws Exception {
        Class<?> net = Class.forName("com.sod.port.Net"), hook = Class.forName("com.sod.port.Hook");
        net.getField("role").setInt(null, 1);
        Field c = net.getDeclaredField("connected"); c.setAccessible(true); c.setBoolean(null, true);
        Field rb = net.getDeclaredField("remoteBits"); rb.setAccessible(true);
        e.first = new b(); hook.getMethod("setHero", Object.class).invoke(null, e.first);
        Method ak = hook.getMethod("ak");
        // ---- cenario 1: P2 PARADO, P1 anda para a direita e a camera segue (3 px/quadro)
        rb.setInt(null, 0);
        ak.invoke(null); int start = h2().K; int minK = start, warps = 0, last = start;
        for (int i = 1; i <= 160; i++) {
            e.first.K += 3; e.first.a = e.first.K << 8; e.T = e.first.K - 100;
            ak.invoke(null);
            int k = h2().K;
            if (k < last - 1 || k > last + 1) warps++;     // salto de posicao = reaparecimento
            last = k;
        }
        System.out.println("CENARIO 1 (P2 parado): K inicial=" + start + "; saltos/reaparecimentos=" + warps + " (esperado >=1, e nenhum arrasto: K nunca acompanha a camera enquanto esta visivel)");
        // ---- cenario 2: P2 parado, P1 anda, conferir que ate sair da tela o P2 NAO se mexeu
        e.first.K = 100; e.first.a = 100 << 8; e.T = 0; ak.invoke(null);
        b p2 = h2(); p2.K = 140; p2.a = 140 << 8; int before = p2.K; boolean moved = false;
        for (int i = 0; i < 25; i++) { e.T += 3; ak.invoke(null); if (p2.K != before) moved = true; }
        System.out.println("CENARIO 2: P2 parado com a camera andando 75 px: posicao mudou? " + moved + " (esperado false; antes era empurrado pela borda)");
        // ---- cenario 3: guest segura DIREITA (esta controlando): parede da borda continua valendo
        rb.setInt(null, 8192);
        for (int i = 0; i < 40; i++) { p2.K += 20; p2.a = p2.K << 8; ak.invoke(null); }
        System.out.println("CENARIO 3 (guest empurrando para a direita): K=" + p2.K + " <= camX+224=" + (e.T + 224) + " ? " + (p2.K <= e.T + 224) + " (esperado true: parede)");
    }
}
