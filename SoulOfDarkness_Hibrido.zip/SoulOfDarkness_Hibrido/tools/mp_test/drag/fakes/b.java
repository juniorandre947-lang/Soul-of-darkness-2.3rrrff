public final class b {
    public static boolean bQ; public static int bO, eP = 10;
    public int K = 100, L = 100, a = 100 << 8, b = 0, G = 0, H = 0, f = 0, h = 0;
    public int[] j = new int[4], k = new int[4];
    public b() { }
    public boolean e() { return false; }
    public void b(int s) { f = s; }
    public void t() { }          // ninguem se mexe sozinho: so a posicao que o Hook mexer
    public void v() { }
}
