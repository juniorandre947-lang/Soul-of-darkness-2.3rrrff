public final class e {
    public static int dg, dh, di, dl, df, dk, dm, dj, T, U, q = 60, r = 60;
    public static b bL, first;
    private static void ak() { if (bL != null) bL.t(); }
    private static void ao() { }
}
