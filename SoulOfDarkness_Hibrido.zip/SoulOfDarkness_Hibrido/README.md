# Soul of Darkness — port nativo para Android

O jogo original (Java/J2ME) roda aqui **dentro de um app Android comum**, sem emulador: o código do jogo
(`app/libs/game.jar`, com o patch do multiplayer; o MOD de vida dos inimigos em dobro foi **removido**) é convertido para dex e conversa com uma
camada de compatibilidade pequena que traduz as APIs do J2ME para as do Android.

## Como gerar o APK
1. Instale o **Android Studio** (versão recente, JDK 17 já vem junto).
2. `File > Open` e escolha esta pasta. Aguarde o *Gradle sync* (precisa de internet na primeira vez;
   ele baixa o Gradle 8.7, o plugin 8.5.2 e o SDK 34 — aceite as licenças se pedir).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
   O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`. Copie para o celular e instale
   (permita "instalar apps desconhecidos"). Para testar direto: ligue o celular por USB e clique em ▶ Run.

## O que tem aqui
| Caminho | Função |
|---|---|
| `app/libs/game.jar` | o jogo (classes + recursos). Troque por outro jar para portar outra versão |
| `javax/microedition/lcdui/*` | Canvas, Graphics, Image, Font, Display... sobre `android.graphics` |
| `javax/microedition/rms/*` | salvamento (RecordStore) em arquivos na pasta interna do app |
| `javax/microedition/media/*` | Player (MIDI/WAV/AMR/MP3) sobre `MediaPlayer` |
| `javax/microedition/midlet/*`, `com/nokia/mid/ui/*` | MIDlet, FullCanvas, DirectGraphics |
| `com/sod/port/MainActivity` | ciclo de vida (start/pause/destroy), teclado físico/gamepad |
| `com/sod/port/GameSurface` | desenha o quadro 240x320 escalado + controles |
| `com/sod/port/Controls` | botões na tela (D-pad, OK, 5/1/3, MENU/VOLTAR, teclado numérico "123") |

## Controles
- **D-pad** (aceita diagonal), **OK** = tecla central (−5), **5 / 1 / 3** = teclas numéricas,
  **MENU / VOLTAR** = softkeys esquerda/direita (−6 / −7), botão **123** abre o teclado numérico completo.
- Teclado/gamepad Bluetooth: setas, Enter, 0–9, `*`, `#`, Menu = softkey esquerda, Voltar = softkey direita.
- Não sei quais teclas fazem o quê no jogo (atacar, pular, magia). Se a ação que você quer não está nos
  botões, abra o teclado "123" e teste; depois ajuste os botões em `Controls.buildButtons()`.

## Se algo der errado
- **Erro do D8 / "class file version 45" no build:** me mande o texto completo do erro.
- **Fecha ao abrir / tela preta:** conecte por USB e veja o Logcat (filtro `SOD` ou `AndroidRuntime`) e me mande.
- **Imagem borrada ou serrilhada demais:** `GameSurface.SMOOTH` (true = suave, false = pixels nítidos).
- **Sem som:** o jogo usa MIDI; alguns aparelhos não tocam MIDI via `MediaPlayer`. Me diga o modelo.
- O Gradle Wrapper (`gradlew`) não está incluso; o Android Studio usa o Gradle indicado em
  `gradle/wrapper/gradle-wrapper.properties`.

## Limitações conhecidas
- Nunca foi executado num Android de verdade por quem escreveu (sem SDK no ambiente de criação): a camada foi
  compilada contra stubs e checada para que **toda** API J2ME usada pelo jogo exista com a assinatura exata,
  mas pode haver diferenças de comportamento (texto, desenho, áudio, desempenho).
- A fonte do texto é a do sistema Android (o jogo usa principalmente fonte própria em sprites).
- O processo é encerrado ao fechar o app (o jogo guarda muito estado em campos `static`).

## Multiplayer: correcao do jogador 2 (teleporte e dano)
- O jogador 2 nao e mais teleportado: fica preso dentro da tela (parede invisivel) e so reaparece junto do
  jogador 1 se cair do mapa ou ficar muito longe (troca de sala).
- `game.jar` agora chama `Hook.pre(inimigo)` / `Hook.post()` em volta da atualizacao de cada inimigo em `e.ak()`
  (feito por `tools/PatchJar.java`, usa o ASM interno do JDK 21). O Hook escolhe como alvo o heroi que esta
  atacando aquele inimigo (ou o mais proximo), entao o jogador 2 passa a dar e receber dano.
- Vida (`e.q`) e invencibilidade temporaria sao estaticos do jogo: a barra de vida e compartilhada pelos dois.
- Nao foi testado em aparelho: se algo falhar, veja o Logcat (filtro `SOD`) e o texto "H2 erro" no canto da tela.

## Multiplayer: correcao da troca de controles (jogador 1 <-> jogador 2)
Causa: as teclas do anfitriao chegam pela thread da interface (`GameSurface.key` -> `keyPressed/keyReleased`), mas o jogo
roda em outra thread. Para mover o heroi 2, `Hook.runAs` troca por alguns instantes as teclas estaticas do jogo
(`e.df/di/dh/...`) pelas do convidado e depois restaura. Sem sincronizacao, um toque do anfitriao nessa janela era lido
pelo heroi 2 (e o valor do convidado vazava de volta para o heroi 1): "as vezes" os controles se misturavam.
- `Hook.INPUT_LOCK`: `runAs` (atualizacao do heroi 2) e `GameSurface.key` seguram a mesma trava, entao a troca de teclas e atomica.
- O desenho do heroi 2 (`bV`) nao troca mais teclas (nao precisa).
- `e.dj` e `b.bQ` (tempo apertado / toque curto, calculados por `e.J()` so com as teclas do anfitriao) agora tem copia propria
  do heroi 2 (`latchHero2()` repete a logica de `e.J()`), em vez de o heroi 2 ler os do heroi 1.
- Toques curtos do convidado (apertar e soltar entre dois quadros) nao se perdem mais (`Net.takeTaps()`, como o `dg` do jogo).
- `pre()/post()` com contador de profundidade: atualizacao de inimigo aninhada nao devolve `e.bL` cedo; `runAs` nao
  sobrescreve `e.bL` se o jogo trocou o heroi no meio (nova fase).
- Rede: o convidado manda um ping por segundo e o anfitriao derruba conexao muda em 6 s (antes, um convidado que sumia sem
  fechar o socket deixava os botoes dele "presos" no heroi 2 e bloqueava a entrada de outro convidado); a fila de teclas
  do convidado e limpa ao reconectar.
- Teste sintetico (sem aparelho): `tools/mp_test/` (classes falsas `e/b/d` + thread de interface martelando teclas).
  Original: vazamento em 4 de 10 execucoes; corrigido: 0 de 10. Nao foi testado em aparelho de verdade.

## Multiplayer: vida propria do jogador 2
O jogo guarda a vida do heroi em estaticos (`e.q` = vida atual, `e.r` = maxima, `b.bO` = invencibilidade), entao os dois
herois dividiam a barra e, se um morria, o outro morria junto.
- `Hook` mantem `hp2`/`inv2` para o heroi 2. `hpIn()/hpOut()` colocam esses valores nos estaticos so enquanto o heroi 2 (ou um
  inimigo que o ataca / um item que ele pega, via `pre()/post()`) esta sendo atualizado; o heroi 1 usa sempre a vida original.
- Heroi 2 morto: toca a animacao de morte, mas `t()` nao e mais chamado no ultimo quadro dela (la o jogo chama `e.a(12)` =
  fim de jogo para todos). Os inimigos deixam de mira-lo; apos `RESPAWN_FRAMES` (100, ~5 s) ele renasce ao lado do heroi 1
  com metade da vida e invencibilidade curta.
- Barra de vida do P2 desenhada no canto superior direito (`drawHud2`).
- Se o heroi 1 morrer continua valendo o fim de jogo normal (a camera e a fase seguem o heroi 1).
- Teste sintetico: `tools/mp_test/hp/`. Nao testado em aparelho.

## Multiplayer: chat de voz
Anfitriao e convidado conversam pela mesma conexao TCP do jogo (sem servidor, sem internet alem do Wi-Fi local).
- `Voice.java`: captura 8 kHz mono (quadros de 20 ms), comprime em mu-law (`Ulaw.java`, G.711, ~64 kbps) e toca o que chega.
  So transmite enquanto voce fala (deteccao de voz com piso de ruido adaptativo + 300 ms de "cauda"); usa a fonte
  `VOICE_COMMUNICATION` e liga o cancelador de eco e o supressor de ruido do Android quando o aparelho tem.
  Se a rede atrasar, quadros velhos sao descartados (a conversa continua em tempo real).
- `Net.java`: novo enquadramento. Convidado->anfitriao: 1 = tecla, 2 = ping, 3 = voz. Anfitriao->convidado: 1 = imagem, 3 = voz.
  Cada mensagem e escrita inteira dentro de `synchronized(o)`; a voz sai por uma thread propria (`net-voice`) com fila limitada.
- Botao **MIC** na tela (so no multiplayer): verde = voce falando, vermelho/"MUDO" = microfone desligado (o microfone do
  aparelho e liberado de verdade), contorno verde = o outro jogador esta falando.
- Permissao `RECORD_AUDIO`: pedida ao criar/entrar numa sala. Sem ela voce ainda ouve o outro jogador.
- Dica: use fones de ouvido; no alto-falante o som do outro pode voltar pelo microfone (eco).
- Testes sinteticos: `tools/mp_test/voice/` (codec e protocolo). Nao testado em aparelho.

## Multiplayer: jogador 2 parado nao e mais arrastado
A camera segue so o heroi 1 e `keepNearHero1` prendia o heroi 2 dentro da tela; quando o heroi 1 andava, a borda empurrava
o heroi 2 parado ("arrastando"). Agora:
- Heroi 2 empurrando esquerda/direita (setas ou 4/6): a borda da tela continua sendo parede.
- Heroi 2 parado: nao e empurrado. Se a camera o deixar fora da tela por `OFF_WARP_FRAMES` (30, ~1,5 s), ele reaparece
  ao lado do heroi 1 (tambem reaparece se cair do mapa ou ficar muito longe, como antes).
- Teste sintetico: `tools/mp_test/drag/` (Hook anterior: 119 quadros de arrasto; agora: 1 reaparecimento).

## Remaster HD (4x)
O jogo continua rodando em 240x320 (logica, colisao, multiplayer), mas o quadro agora e desenhado em
**960x1280** (`HdPack.SCALE = 4`) e cada imagem carregada ganha uma versao 4x maior:
- **Automatico, sem fazer nada:** sprites/HUD/imagens pequenas ou com transparencia usam pixel art (EPX x2, sem
  cores novas, bordas nitidas); fundos, tilesets e retratos sem transparencia usam bicubico (`Upscale.java`).
- **Qualidade maxima (opcional):** na primeira execucao o app grava cada PNG que o jogo cria em
  `Android/data/com.sod.port/files/dump/` (jogue todas as fases para pegar tudo; `HdPack.DUMP`).
  No PC: `python tools/upscale_hd.py dump hd --esrgan caminho/realesrgan-ncnn-vulkan` (a IA so e usada nos
  fundos; sprites seguem em pixel art). Copie a pasta `hd/` para `Android/data/com.sod.port/files/hd/`
  (ou para `app/src/main/assets/hd/` e gere o APK de novo). O nome do arquivo e o CRC32 do PNG original.
  Cada variante de paleta que o jogo montar vira uma imagem diferente, entao cada uma e ampliada separadamente.
- Mude o fator em `HdPack.SCALE` (2, 4 ou 8) e use o mesmo `--scale` no script. 8x = 1920x2560 (mais memoria).
- Se faltar memoria numa imagem, ela volta para o original (pixelada) e o log `SOD` avisa; `largeHeap` esta ligado.
- Multiplayer: o convidado continua recebendo o quadro em 240x320 (a rede nao carrega HD).
- Nao testado em aparelho (sem SDK aqui): a camada J2ME + HdPack + Upscale compila contra stubs, e o EPX do Java
  foi conferido pixel a pixel com o do script Python.

## Visual extra (PostFx.java) e fundos limpos
- **Fundos:** antes de ampliar, tira o quadriculado (dithering) com um filtro que preserva as bordas
  (`Upscale.dedither`; o `upscale_hd.py` faz o mesmo antes da IA). O halo da lua vira degradê em vez de pontinhos.
- **PostFx** (por cima do quadro, so visual): correcao de cor (contraste/saturacao/tom quente), **brilho (bloom)**
  nas partes claras, **vinheta** nos cantos e **faiscas** flutuando (cor acompanha a cena). Cada efeito liga/desliga
  nas constantes no topo de `PostFx.java` (`GRADE`, `BLOOM`, `VIGNETTE`, `EMBERS`, ou `ENABLED` para tudo).
  Intensidades: `BLOOM_THRESHOLD/GAIN/ALPHA_*`, `VIGNETTE_STRENGTH`, `EMBER_COUNT`.
- Se o aparelho for lento (bloom gastando >14 ms por quadro), o bloom e as faiscas desligam sozinhos.
- Limite conhecido: a ampliacao suave pode deixar uma emenda fraca na borda de tiles que ficam colados no atlas.

## MOD de vida dos inimigos em dobro: removido
- O MOD era o metodo `zzHP(I)I` em `b.class` (= `C(I) * 2`), chamado em 15 pontos no lugar de `C(I)` ao definir a
  vida do inimigo (`b.as = ...`). `tools/RevertHpMod.java` troca as 15 chamadas de volta para `C` e apaga `zzHP`:
  a vida dos inimigos volta ao valor original do jogo. So `b.class` muda; o resto do jar fica identico.
- Backup do jar com o MOD (vida 2x): `tools/backup/game_vida_inimigos_2x.jar` (para voltar, copie sobre `app/libs/game.jar`).
- Refazer: `java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports
  java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED tools/RevertHpMod.java entrada.jar saida.jar` (JDK 21).

## Dobro de inimigos nas fases: removido (dados restaurados do jar original)
- O dobro de inimigos estava nos **dados das fases** (`3` a `12` dentro do `game.jar`): registros de entidades extras
  (ids sequenciais novos, ex.: 0xa3..0xab) inseridos nas listas de cada sala, com a tabela de offsets deslocada.
- Comparado com `Soul_Of_Darkness_BR_240x320.jar` (original): os 10 arquivos `3`..`12` foram **restaurados byte a byte**.
  Os demais recursos (0-2, 13-24, `dataIGP`, imagens) ja eram identicos ao original.
- Diferencas que sobraram no `game.jar` em relacao ao original, todas intencionais do port (so codigo):
  `a.class` (2x `getClass` -> `Res.c`), `b.class` (1 chamada -> `Hook.setHero`), `e.class` (chamadas ao `Hook` do multiplayer).
- Backup do jar com os inimigos em dobro: `tools/backup/game_inimigos_2x_dados.jar`.
- Saves antigos (RMS) feitos com o mod ainda podem apontar para estados de fase do mod: se algo estranho aparecer,
  limpe os dados do app (Configuracoes > Apps > Soul of Darkness > Armazenamento > Limpar dados) e comece de novo.

## Audio da versao DSi no jogo original
Trilhas e efeitos vem da ROM do Soul of Darkness (DSi), convertidos do `SoD.sdat` para OGG (`assets/mus`, `assets/sfx`).
- **Musicas/jingles:** `AndroidPlayer.replacement()` troca o MIDI pelo OGG correspondente. O id do som e `e.fv` e a fase e `e.aX`:
  0 titulo, 4 chefe aparece, 5 morte, 6 fase completa, 7 creditos, 8 tema de amor; 1/2/3 = musica da fase
  (castelo, capitulo 2, selva, capitulo 4, capitulo 8, capitulo 9, lava, conforme `e.aX`).
- **Efeitos do Kale (pulo, ataque, dano, morte):** `tools/PatchSfx.java` insere `SfxHook.play(id)` em `b.class`
  (pulo: `H = -2560/-3328` em `aZ`; ataque: criacao dos tipos 300/302/303 em `aZ`; dano: `d(I)Z`; morte: `b.b(12)`).
  Refazer: `java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED tools/PatchSfx.java entrada.jar saida.jar`.
- A versao HTML5 do DSi foi removida deste projeto.
- Nao testado em aparelho.

## Desempenho: travamentos e 60 fps (otimizacao)
**Causa dos travamentos.** O jogo e J2ME: a logica anda a 20 quadros/s (50 ms por quadro; 66 ms em alguns estados) e pintava de
forma *sincrona*: a mesma thread desenhava 960x1280 por CPU, aplicava cor + bloom + vinheta por CPU em tela cheia e so entao
dormia. Quando isso passava de 50 ms o jogo inteiro ficava em camera lenta. Alem disso havia:
- `System.gc()` chamado a mao em 19 pontos do jogo (cada um bloqueia numa coleta completa no Android);
- ampliacao HD (EPX/bicubico em Java) feita na hora a cada imagem/variante de paleta, e de novo toda vez que o jogo recriava a imagem;
- `drawRGB` criando um Bitmap novo por sprite por quadro, `Font` recriada, `RectF` novo por botao por quadro.

**O que mudou.**
| Onde | Mudanca |
|---|---|
| `GameSurface` | O jogo pinta e **copia o quadro** para um de 2 buffers (`Snap`) sem esperar a tela. Uma **thread de video** (`Renderer`) redesenha o quadro mais recente a cada vsync (alvo 60 Hz) com `lockHardwareCanvas()` (GPU, API 26+; abaixo disso ou se falhar, CPU). Escala, cor, bloom, vinheta e faiscas saem da GPU. |
| `PostFx` | O halo do bloom (CPU, ~1-2 ms) e calculado **1x por quadro do jogo**, nao a cada apresentacao. Desenho/efeitos rodam a 60 Hz. As faiscas animam suaves a 60 fps. |
| `tools/PatchGc.java` + `Res.gc()` | As 19 chamadas `System.gc()` do `game.jar` viraram no-op (so `a`, `d`, `e` mudaram; bytecode verificado). Backup do jar anterior: `tools/backup/game_antes_otimizacao.jar`. |
| `HdPack` | Cache LRU em memoria + **cache em disco** (`files/hdcache`, gravado em segundo plano): a ampliacao so custa na 1a vez que cada imagem aparece. Lista os arquivos do pacote `hd/` uma vez (nada de abrir asset inexistente a cada imagem). `DUMP` nao regrava arquivos que ja existem e grava em segundo plano. |
| `Graphics` / `Font` / `Controls` | `drawRGB` reaproveita o bitmap; `Font.getFont` com cache; menos alocacao por quadro. |
| Thread do jogo | Prioridade de video (`THREAD_PRIORITY_DISPLAY`). |

**Limite importante: 60 fps de tela, 20 de logica.** A *apresentacao* agora e 60 Hz e estavel, mas personagens e inimigos so
mudam de posicao 20 vezes por segundo, como no original (aumentar isso aceleraria o jogo todo, ja que a logica conta quadros).
Para movimento visualmente mais fluido seria preciso interpolar sprites entre dois quadros da logica (da pra fazer, com algum custo de latencia).

**Se ainda pesar num aparelho fraco:** em `HdPack.SCALE` use `2` (quadro de 480x640, ~4x menos pixels). A primeira vez em cada fase
ainda faz a ampliacao (um engasgo unico); depois vem do cache em disco. Nao testado em aparelho (sem SDK aqui): as classes alteradas compilam
contra stubs da API Android e o `game.jar` passa em `-Xverify:all`.

## Sons da versao DSi (efeitos)
Os sons vieram do `SoD.sdat` da ROM DSi (tools/sdat/). O sintetizador (`tools/sdat/synth.py`) le SWAR (ADPCM), SBNK e SSEQ
e foi validado contra os 4 efeitos antigos (correlacao 0,95-0,97). Foram renderizados **48 efeitos** (`assets/sfx/`, 56 arquivos,
com as variantes que o DS sorteia, ex.: `SFX_HIT`, `SFX_WALKING`) e `index.txt` (nome|variantes|jitter de pitch|loop).
`SfxHook` toca por id (0 pulo, 1 chicote, 2 dano, 3 morte: ja ligados no jogo) ou por nome: `SfxHook.play("SFX_EXPLOSION")`.

**Ainda NAO ligados ao jogo:** menus, pickups, inimigos, portas, elevador, laser, etc. O jogo J2ME original nao tinha efeitos;
cada um precisa de um gancho no codigo ofuscado (`b.class`/`e.class`) e eu nao consegui validar nenhum deles.
Tambem nao foram refeitas as musicas nem verificado o mapa fase->musica (`AndroidPlayer.replacement`).
Harness de teste sem tela: ver a pasta `headless/` (sobe o jogo no PC; chega ate o menu e a carga da fase 1).

## Sons de inimigos (ataque) - engenharia reversa do game.jar
Mapa descoberto: o despachante `b.t()` liga o **tipo da entidade** (`b.ao`) a um metodo de IA; `b.bs[tipo]` da o indice do sprite e os nomes
vem do `res.bar` do DSi (a ordem dos 52 primeiros sprites e igual no J2ME):
| tipo | sprite | metodo de IA | som ligado |
|---|---|---|---|
| 1 | zombie | `bu` | SFX_ZOMBIE_ATTACK |
| 8 | bigeye | `bB` | SFX_BOSS_EYE_TAUNT |
| 11 | werewolf | `bF` | SFX_WEREWOLF_GROWL |
| 15 | fish | `cf` | SFX_FISH_ATTACKS |
| 83 | dragon | `bR` | SFX_DRAGON (intervalo de 4 s: o som dura ~8 s) |
| 99 | girl | `aP` | SFX_VAMPIRE_GIRL_HIT |
| 2,3 imp / 4 ghost / 5 shadow_hand / 9 bighand / 10 laser_bat / 13 poison_ball / 14 waterelement / 90,100 boss_03 | | `br bt bz bA bC bE bH bJ bO bQ` | so log (sem som proprio no DSi) |
`tools/PatchEnemySfx.java` insere `SfxHook.enemy(tipo)` antes de cada spawn de objeto de ataque (300/302/303/308) dentro desses metodos.
**Nao testado em aparelho.** Se algum som tocar na hora errada (ex.: no impacto em vez de no ataque), veja `adb logcat -s SOD`:
cada disparo imprime "inimigo tipo N ataca -> SFX_...". Backup do jar anterior: `tools/backup/game_antes_inimigos.jar`.
**Ainda sem som:** inimigo ATINGIDO e inimigo MORRENDO (nao achei o metodo de dano do inimigo), bosses especificos, cutscenes (opcode 102 e hipotese).
