package javax.microedition.midlet;

import javax.microedition.io.ConnectionNotFoundException;

public abstract class MIDlet {
    /** Ponte para o Android (implementada pela MainActivity). */
    public interface Host {
        void notifyDestroyed();
        String getAppProperty(String key);
        boolean platformRequest(String url);
    }
    public static Host host;

    protected MIDlet() { }

    protected abstract void startApp() throws MIDletStateChangeException;
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean unconditional) throws MIDletStateChangeException;

    public final void notifyDestroyed() { if (host != null) host.notifyDestroyed(); }
    public final void notifyPaused() { }
    public final void resumeRequest() { }
    public final String getAppProperty(String key) { return host != null ? host.getAppProperty(key) : null; }
    public final boolean platformRequest(String url) throws ConnectionNotFoundException {
        return host != null && host.platformRequest(url);
    }

    // ---- usados pelo launcher Android ----
    public final void __start() throws MIDletStateChangeException { startApp(); }
    public final void __pause() { pauseApp(); }
    public final void __destroy() throws MIDletStateChangeException { destroyApp(true); }
}
