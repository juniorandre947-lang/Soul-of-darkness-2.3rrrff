package javax.microedition.rms;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/** RMS persistido em arquivos na pasta interna do app (um arquivo por record store). */
public class RecordStore {
    private static File dir;
    public static void init(File d) { dir = d; }

    private final File file;
    private final ArrayList<byte[]> recs = new ArrayList<byte[]>();

    private RecordStore(File f) { file = f; }

    public static synchronized RecordStore openRecordStore(String name, boolean create) throws RecordStoreException {
        File f = new File(dir, "rms_" + name.replaceAll("[^A-Za-z0-9_.-]", "_") + ".dat");
        if (!f.exists() && !create) throw new RecordStoreNotFoundException(name);
        RecordStore rs = new RecordStore(f);
        rs.load();
        return rs;
    }

    private void load() throws RecordStoreException {
        if (!file.exists()) return;
        try {
            DataInputStream in = new DataInputStream(new FileInputStream(file));
            try {
                int n = in.readInt();
                for (int i = 0; i < n; i++) {
                    byte[] b = new byte[in.readInt()];
                    in.readFully(b);
                    recs.add(b);
                }
            } finally { in.close(); }
        } catch (IOException e) {
            throw new RecordStoreException(String.valueOf(e));
        }
    }

    private void save() throws RecordStoreException {
        try {
            File tmp = new File(file.getPath() + ".tmp");
            DataOutputStream out = new DataOutputStream(new FileOutputStream(tmp));
            try {
                out.writeInt(recs.size());
                for (byte[] b : recs) { out.writeInt(b.length); out.write(b); }
            } finally { out.close(); }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (IOException e) {
            throw new RecordStoreException(String.valueOf(e));
        }
    }

    public synchronized void closeRecordStore() { }
    public synchronized int getNumRecords() { return recs.size(); }

    public synchronized int addRecord(byte[] data, int offset, int numBytes) throws RecordStoreException {
        byte[] b = new byte[numBytes];
        if (data != null) System.arraycopy(data, offset, b, 0, numBytes);
        recs.add(b);
        save();
        return recs.size(); // ids comecam em 1
    }

    public synchronized int getRecord(int id, byte[] buffer, int offset) throws RecordStoreException {
        if (id < 1 || id > recs.size()) throw new InvalidRecordIDException(String.valueOf(id));
        byte[] b = recs.get(id - 1);
        System.arraycopy(b, 0, buffer, offset, b.length);
        return b.length;
    }

    public synchronized void setRecord(int id, byte[] data, int offset, int numBytes) throws RecordStoreException {
        if (id < 1 || id > recs.size()) throw new InvalidRecordIDException(String.valueOf(id));
        byte[] b = new byte[numBytes];
        if (data != null) System.arraycopy(data, offset, b, 0, numBytes);
        recs.set(id - 1, b);
        save();
    }
}
