package javax.microedition.lcdui;

import android.graphics.Paint;
import android.graphics.Typeface;

public final class Font {
    public static final int FACE_SYSTEM = 0, FACE_MONOSPACE = 32, FACE_PROPORTIONAL = 64;
    public static final int STYLE_PLAIN = 0, STYLE_BOLD = 1, STYLE_ITALIC = 2, STYLE_UNDERLINED = 4;
    public static final int SIZE_MEDIUM = 0, SIZE_SMALL = 8, SIZE_LARGE = 16;

    private static final Font DEFAULT = new Font(FACE_SYSTEM, STYLE_PLAIN, SIZE_MEDIUM);

    private final int face, style, size;
    private final Paint paint = new Paint();
    private final Typeface typeface;
    private final float px;

    private Font(int face, int style, int size) {
        this.face = face; this.style = style; this.size = size;
        int ts = (style & STYLE_BOLD) != 0 ? ((style & STYLE_ITALIC) != 0 ? Typeface.BOLD_ITALIC : Typeface.BOLD)
                : ((style & STYLE_ITALIC) != 0 ? Typeface.ITALIC : Typeface.NORMAL);
        Typeface base = face == FACE_MONOSPACE ? Typeface.MONOSPACE : Typeface.SANS_SERIF;
        typeface = Typeface.create(base, ts);
        px = size == SIZE_SMALL ? 11f : size == SIZE_LARGE ? 18f : 14f;
        apply(paint);
    }

    // O jogo pode pedir a mesma fonte todo quadro: cada Font cria Paint+Typeface, entao reaproveita.
    private static final java.util.HashMap<Integer, Font> CACHE = new java.util.HashMap<Integer, Font>();

    public static synchronized Font getFont(int face, int style, int size) {
        Integer k = Integer.valueOf((face << 16) | (style << 8) | size);
        Font f = CACHE.get(k);
        if (f == null) { f = new Font(face, style, size); CACHE.put(k, f); }
        return f;
    }
    public static Font getDefaultFont() { return DEFAULT; }

    /** Aplica este fonte a um Paint (usado por Graphics). */
    void apply(Paint p) {
        p.setTypeface(typeface);
        p.setTextSize(px);
        p.setUnderlineText((style & STYLE_UNDERLINED) != 0);
    }

    public int getHeight() { Paint.FontMetricsInt fm = paint.getFontMetricsInt(); return fm.descent - fm.ascent; }
    public int getBaselinePosition() { return -paint.getFontMetricsInt().ascent; }
    public int stringWidth(String s) { return (int) Math.ceil(paint.measureText(s)); }
    public int charWidth(char c) { return (int) Math.ceil(paint.measureText(String.valueOf(c))); }
    public int getFace() { return face; }
    public int getStyle() { return style; }
    public int getSize() { return size; }
}
