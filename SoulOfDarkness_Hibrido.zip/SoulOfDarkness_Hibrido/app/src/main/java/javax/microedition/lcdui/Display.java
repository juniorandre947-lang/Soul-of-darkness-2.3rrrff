package javax.microedition.lcdui;

import javax.microedition.midlet.MIDlet;

public class Display {
    public static final int WIDTH = 240, HEIGHT = 320;

    /** Ponte para a superficie Android. */
    public interface Host {
        void repaint(Canvas c);
    }
    public static volatile Host host;

    private static final Display INSTANCE = new Display();
    private volatile Displayable current;

    private Display() { }

    public static Display getDisplay(MIDlet m) { return INSTANCE; }

    public void setCurrent(Displayable d) {
        current = d;
        if (d instanceof Canvas) {
            ((Canvas) d).__showNotify();
            Host h = host;
            if (h != null) { try { h.repaint((Canvas) d); } catch (Throwable ignore) { } }
        }
    }
    public Displayable getCurrent() { return current; }

    public static Canvas currentCanvas() {
        Displayable d = INSTANCE.current;
        return d instanceof Canvas ? (Canvas) d : null;
    }
}
