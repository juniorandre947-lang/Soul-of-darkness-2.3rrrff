package javax.microedition.media;

import android.media.MediaPlayer;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Player do MMAPI em cima de MediaPlayer (o audio vai para um arquivo temporario). */
final class AndroidPlayer implements Player, MediaPlayer.OnCompletionListener {
    private static int counter;
    private MediaPlayer mp;
    private File file;
    private int state = UNREALIZED;
    private int loops = 1, played;
    private boolean prepared;

    AndroidPlayer(InputStream in, String type) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        byte[] d = bo.toByteArray();
        String rep = replacement();
        if (rep != null) {
            try {
                InputStream is = Manager.assets.open(rep);
                try {
                    ByteArrayOutputStream b2 = new ByteArrayOutputStream();
                    byte[] bf = new byte[8192]; int k;
                    while ((k = is.read(bf)) > 0) b2.write(bf, 0, k);
                    d = b2.toByteArray();
                } finally { is.close(); }
            } catch (Throwable t) { /* sem o arquivo: usa o MIDI original */ }
        }
        File dir = Manager.cacheDir != null ? Manager.cacheDir : new File(System.getProperty("java.io.tmpdir", "."));
        synchronized (AndroidPlayer.class) { file = new File(dir, "snd" + (counter++) + ext(type, d)); }
        FileOutputStream fo = new FileOutputStream(file);
        try { fo.write(d); } finally { fo.close(); }
        file.deleteOnExit();
    }

    private static int stat(String n) {
        try {
            java.lang.reflect.Field f = Class.forName("e").getDeclaredField(n);
            f.setAccessible(true);
            return f.getInt(null);
        } catch (Throwable t) { return -99; }
    }

    /** Musicas e jingles da versao DSi no lugar dos MIDI do jogo (assets/mus). e.fv = id do som, e.aX = fase. */
    private static String replacement() {
        if (Manager.assets == null) return null;
        int id = stat("fv"), lvl = stat("aX");
        String n = null;
        switch (id) {
            case 0: n = "m_title"; break;
            case 4: n = "m_boss_appear"; break;
            case 5: n = "m_death"; break;
            case 6: n = "m_level_complete"; break;
            case 7: n = "m_credits"; break;
            case 8: n = "m_love"; break;
            case 1: case 2: case 3: {
                String[] t = { "m_castle", "m_chapter_2", "m_jungle", "m_chapter_4", "m_jungle",
                               "m_castle", "m_castle", "m_chapter_8", "m_chapter_9", "m_lava" };
                if (lvl >= 0 && lvl < t.length) n = t[lvl];
                else n = id == 1 ? "m_castle" : id == 2 ? "m_jungle" : "m_lava";
                break;
            }
            default: break;
        }
        return n == null ? null : "mus/" + n + ".ogg";
    }

    private static String ext(String type, byte[] d) {
        if (d.length > 4) {
            if (d[0] == 'O' && d[1] == 'g' && d[2] == 'g' && d[3] == 'S') return ".ogg";
            if (d[0] == 'M' && d[1] == 'T' && d[2] == 'h' && d[3] == 'd') return ".mid";
            if (d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F') return ".wav";
            if (d[0] == '#' && d[1] == '!' && d[2] == 'A' && d[3] == 'M') return ".amr";
            if (d[0] == 'I' && d[1] == 'D' && d[2] == '3') return ".mp3";
        }
        if (type != null) {
            String t = type.toLowerCase();
            if (t.contains("wav")) return ".wav";
            if (t.contains("amr")) return ".amr";
            if (t.contains("mpeg") || t.contains("mp3")) return ".mp3";
        }
        return ".mid";
    }

    public synchronized void realize() { if (state == UNREALIZED) state = REALIZED; }

    public synchronized void prefetch() throws MediaException {
        realize();
        if (state >= PREFETCHED) return;
        try {
            if (mp == null) {
                mp = new MediaPlayer();
                mp.setOnCompletionListener(this);
                mp.setDataSource(file.getPath());
            }
            if (!prepared) { mp.prepare(); prepared = true; }
            state = PREFETCHED;
        } catch (Exception e) {
            throw new MediaException(String.valueOf(e));
        }
    }

    public synchronized void start() throws MediaException {
        prefetch();
        try {
            played = 0;
            mp.setLooping(loops == -1);
            mp.start();
            state = STARTED;
        } catch (Exception e) {
            throw new MediaException(String.valueOf(e));
        }
    }

    public synchronized void stop() throws MediaException {
        if (mp != null && state == STARTED) {
            try { mp.pause(); } catch (Exception ignore) { }
            state = PREFETCHED;
        }
    }

    public synchronized void deallocate() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignore) { }
            try { mp.reset(); } catch (Exception ignore) { }
            try { mp.release(); } catch (Exception ignore) { }
            mp = null; prepared = false;
        }
        if (state > REALIZED) state = REALIZED;
    }

    public synchronized void close() {
        deallocate();
        state = CLOSED;
        if (file != null) { file.delete(); file = null; }
    }

    public synchronized int getState() { return state; }

    public synchronized void setLoopCount(int count) {
        loops = count;
        if (mp != null) { try { mp.setLooping(count == -1); } catch (Exception ignore) { } }
    }

    public synchronized void onCompletion(MediaPlayer m) {
        played++;
        if (loops > 1 && played < loops) {
            try { m.seekTo(0); m.start(); return; } catch (Exception ignore) { }
        }
        state = PREFETCHED;
    }
}
