package javax.microedition.rms;

public class RecordStoreNotFoundException extends RecordStoreException {
    public RecordStoreNotFoundException(String s) { super(s); }
}
