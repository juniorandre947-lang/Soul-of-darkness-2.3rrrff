package com.sod.port;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Multiplayer por Wi-Fi local (TCP).
 *  - ANFITRIAO roda o jogo (com o heroi 2) e envia a imagem (JPEG) para o convidado.
 *  - CONVIDADO so mostra a imagem recebida e envia os botoes que aperta.
 */
public final class Net {
    private Net() { }

    public static final int SOLO = 0, HOST = 1, GUEST = 2;
    public static final int PORT = 5555;

    /** Quem fornece a imagem do jogo e redesenha a tela (implementado por GameSurface). */
    public interface Source {
        byte[] grabJpeg();
        void refresh();
    }

    public static volatile int role = SOLO;
    private static volatile boolean connected;
    private static volatile int remoteBits;            // anfitriao: botoes do convidado (formato do jogo)
    /** anfitriao: botoes que o convidado apertou desde o ultimo quadro (inclui toques ja soltos). */
    private static final AtomicInteger remoteTaps = new AtomicInteger();
    private static volatile Bitmap guestFrame;         // convidado: ultimo quadro recebido
    private static volatile Socket sock;
    private static final LinkedBlockingQueue<int[]> outQueue = new LinkedBlockingQueue<int[]>();
    /** Quadros de voz (mu-law) esperando para serem enviados ao outro jogador. */
    private static final LinkedBlockingQueue<byte[]> voiceOut = new LinkedBlockingQueue<byte[]>(50);

    // Protocolo (TCP). Convidado -> anfitriao: 1 = tecla (short codigo, boolean down), 2 = ping, 3 = voz (short n, n bytes).
    // Anfitriao -> convidado: 1 = imagem (int n, n bytes JPEG), 3 = voz (short n, n bytes).
    // Cada mensagem e escrita inteira dentro de synchronized(o), porque imagem, teclas, ping e voz saem de threads diferentes.
    private static final int MSG_FRAME_OR_KEY = 1, MSG_PING = 2, MSG_VOICE = 3, MAX_VOICE = 4000;

    /** Chamado pelo microfone (Voice): so enfileira; se a rede estiver lenta o quadro velho e descartado. */
    public static void sendVoice(byte[] ulaw) {
        if (!connected) return;
        if (!voiceOut.offer(ulaw)) { voiceOut.poll(); voiceOut.offer(ulaw); }
    }

    /** Thread que envia a voz da fila (uma por conexao). */
    private static Thread voiceSender(final Socket s, final DataOutputStream o) {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    while (connected && sock == s) {
                        byte[] v = voiceOut.poll(200, TimeUnit.MILLISECONDS);
                        if (v == null) continue;
                        synchronized (o) {
                            o.writeByte(MSG_VOICE);
                            o.writeShort(v.length);
                            o.write(v);
                            o.flush();
                        }
                    }
                } catch (Throwable ignore) {
                }
            }
        }, "net-voice");
        t.setDaemon(true);
        return t;
    }

    private static void readVoice(DataInputStream in) throws java.io.IOException {
        int len = in.readUnsignedShort();
        if (len <= 0 || len > MAX_VOICE) throw new java.io.IOException("voz invalida: " + len);
        byte[] v = new byte[len];
        in.readFully(v);
        Voice.onRemote(v);
    }

    public static boolean connected() { return connected; }
    public static int remoteBits() { return remoteBits; }
    /** Botoes apertados pelo convidado desde a ultima chamada (e zera). Um toque mais curto que um quadro nao se perde. */
    public static int takeTaps() { return remoteTaps.getAndSet(0); }

    private static void addTap(int bit) {
        int o;
        do { o = remoteTaps.get(); } while (!remoteTaps.compareAndSet(o, o | bit));
    }
    public static Bitmap guestFrame() { return guestFrame; }

    // ------------------------------------------------------------------ anfitriao

    public static void startHost(final Source src) {
        role = HOST;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ServerSocket server = new ServerSocket();
                    server.setReuseAddress(true);
                    server.bind(new InetSocketAddress(PORT));
                    while (true) {
                        Socket s = server.accept();
                        handleGuest(s, src);
                    }
                } catch (Throwable e) {
                    Hook.status = "Sala com erro: " + e;
                }
            }
        }, "net-host");
        t.setDaemon(true);
        t.start();
    }

    private static void handleGuest(final Socket s, final Source src) {
        try {
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            // o convidado manda um "ping" por segundo: sem nada por 6 s a conexao morreu (Wi-Fi caiu, app fechado)
            // e os botoes dele nao podem ficar "presos" no heroi 2 nem bloquear a entrada de um novo convidado
            s.setSoTimeout(6000);
            sock = s;
            remoteBits = 0;
            remoteTaps.set(0);
            voiceOut.clear();
            connected = true;
            Voice.start();
            Hook.status = "Jogador 2 conectado";
            final DataOutputStream o = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            Thread sender = new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        while (connected && sock == s) {
                            byte[] jpg = src.grabJpeg();
                            if (jpg != null) {
                                synchronized (o) { o.writeByte(MSG_FRAME_OR_KEY); o.writeInt(jpg.length); o.write(jpg); o.flush(); }
                            }
                            Thread.sleep(40);
                        }
                    } catch (Throwable ignore) {
                    }
                }
            }, "net-send");
            sender.setDaemon(true);
            sender.start();
            voiceSender(s, o).start();
            while (true) {
                int type = in.readUnsignedByte();
                if (type == 1) {
                    int code = in.readShort();
                    boolean down = in.readBoolean();
                    int bit = bitFor(code);
                    if (down) { remoteBits |= bit; addTap(bit); } else remoteBits &= ~bit;
                } else if (type == MSG_VOICE) {
                    readVoice(in);
                } else if (type != MSG_PING) {          // 2 = ping; qualquer outra coisa = fluxo corrompido
                    throw new java.io.IOException("protocolo invalido: " + type);
                }
            }
        } catch (Throwable ignore) {
        } finally {
            if (sock == s) { connected = false; Voice.stop(); }
            remoteBits = 0;
            remoteTaps.set(0);
            try { s.close(); } catch (Throwable ignore) { }
            Hook.status = "Jogador 2 saiu. Aguardando...";
        }
    }

    /** Codigo de tecla J2ME -> bit usado pelo jogo (mesma tabela do metodo e.Y do jogo). */
    static int bitFor(int code) {
        switch (code) {
            case -1: return 16384;   // cima
            case -2: return 32768;   // baixo
            case -3: return 4096;    // esquerda
            case -4: return 8192;    // direita
            case -5: return 65536;   // OK
            case -6: return 262144;  // menu
            case -7: return 131072;  // voltar
            case 35: return 1024;    // #
            case 42: return 2048;    // *
            default:
                if (code >= '0' && code <= '9') return 1 << (code - '0');
                return 0;
        }
    }

    // ------------------------------------------------------------------ convidado

    public static void connect(final String ip, final Source src) {
        role = GUEST;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                Socket s = null;
                try {
                    Hook.status = "Conectando a " + ip + " ...";
                    s = new Socket();
                    s.connect(new InetSocketAddress(ip, PORT), 6000);
                    s.setTcpNoDelay(true);
                    outQueue.clear();                  // teclas de uma conexao anterior nao podem ser reenviadas nesta
                    voiceOut.clear();
                    sock = s;
                    connected = true;
                    Voice.start();
                    Hook.status = "Conectado. Aguardando imagem...";
                    final DataOutputStream o = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
                    DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
                    final Socket fs = s;
                    Thread writer = new Thread(new Runnable() {
                        @Override public void run() {
                            try {
                                while (connected && sock == fs) {
                                    int[] k = outQueue.poll(1000, TimeUnit.MILLISECONDS);
                                    synchronized (o) {
                                        if (k == null) { o.writeByte(MSG_PING); o.flush(); continue; }   // ping (mantem a conexao viva)
                                        o.writeByte(MSG_FRAME_OR_KEY);
                                        o.writeShort(k[0]);
                                        o.writeBoolean(k[1] != 0);
                                        o.flush();
                                    }
                                }
                            } catch (Throwable ignore) {
                            }
                        }
                    }, "net-keys");
                    writer.setDaemon(true);
                    writer.start();
                    voiceSender(s, o).start();
                    boolean first = true;
                    while (true) {
                        int type = in.readUnsignedByte();
                        if (type == MSG_VOICE) { readVoice(in); continue; }
                        if (type != MSG_FRAME_OR_KEY) throw new java.io.IOException("protocolo invalido: " + type);
                        int len = in.readInt();
                        if (len <= 0 || len > 500000) throw new java.io.IOException("quadro invalido");
                        byte[] b = new byte[len];
                        in.readFully(b);
                        Bitmap bm = BitmapFactory.decodeByteArray(b, 0, len);
                        if (bm != null) {
                            guestFrame = bm;
                            if (first) { first = false; Hook.status = null; }
                            src.refresh();
                        }
                    }
                } catch (Throwable e) {
                    Hook.status = "Conexao perdida: " + e;
                } finally {
                    if (sock == s) { connected = false; Voice.stop(); }
                    if (s != null) { try { s.close(); } catch (Throwable ignore) { } }
                    src.refresh();
                }
            }
        }, "net-guest");
        t.setDaemon(true);
        t.start();
    }

    /** Chamado pela interface (thread principal): so coloca na fila, quem envia e outra thread. */
    public static void sendKey(int code, boolean down) {
        if (!connected) return;
        outQueue.offer(new int[] { code, down ? 1 : 0 });
    }
}
