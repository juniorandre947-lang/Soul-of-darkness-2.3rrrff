package com.sod.port;

import javax.microedition.lcdui.Graphics;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * EXPERIMENTO multiplayer, passo 2: o segundo heroi (clone do primeiro) e controlado pelos botoes do convidado (rede).
 * O game.jar foi ajustado para chamar estes metodos no lugar de:
 *   e.ak()  (atualiza o heroi e os inimigos)  -> Hook.ak()
 *   e.ao()  (desenha a fase)                  -> Hook.ao()
 *   putstatic e.bL (guarda o heroi)           -> Hook.setHero(obj)
 */
public final class Hook {
    private Hook() { }

    /** Texto curto mostrado no canto da tela (GameSurface). */
    public static volatile String status = null;

    /**
     * Trava das teclas estaticas do jogo (e.df/di/dh/dg/dl/dk...). As teclas do anfitriao chegam pela thread da interface
     * (GameSurface.key -> keyPressed/keyReleased) enquanto o jogo roda em outra thread. Para mover o heroi 2 o Hook troca
     * essas teclas por alguns instantes (runAs); sem trava, um toque do anfitriao nessa janela era lido pelo heroi 2 e o
     * valor do convidado vazava para o heroi 1 ("jogador 1 controla o 2 e vice-versa"). Quem escreve tecla segura esta trava.
     */
    public static final Object INPUT_LOCK = new Object();

    /** O heroi 2 so existe quando sou o anfitriao e ha um convidado conectado. */
    private static boolean active() {
        return Net.role == Net.HOST && Net.connected();
    }

    private static int curHeld, curPressed, curReleased, prevHeld;
    /** Estado proprio do heroi 2 para o que e.J() calcula a partir das teclas (e.dj = tempo apertado, b.bQ = toque curto). */
    private static int dj2 = -1, prevPressed2;
    private static boolean bQ2;
    /** Profundidade de pre()/post(): atualizacoes de inimigo aninhadas nao podem devolver e.bL cedo demais. */
    private static int depth;
    /** Botoes de movimento valem enquanto segurados; os demais (ataque etc.) valem so no instante do toque. */
    private static final int HELD_BITS = 4096 | 8192 | 16384 | 32768 | 4 | 16 | 64 | 256 | 2 | 8;
    private static final int SOFTKEYS = 131072 | 262144;

    private static Class<?> E, B, D;
    private static Field eBL, eT, eU, fJ, fK, eDj, eDk, bBQ;
    private static Field eQ, eR, bBO, bEP, eD;          // vida (e.q), vida maxima (e.r), invencibilidade (b.bO), duracao (b.eP), Graphics do jogo (e.d)
    private static Method bE, bB;                       // b.e() = animacao terminou; b.b(int) = muda o estado do heroi

    // ---- vida PROPRIA do jogador 2 ----
    // O jogo guarda a vida do heroi em estaticos (e.q e b.bO), entao os dois herois dividiam a mesma barra e, se um morria,
    // o outro morria junto. Agora o heroi 2 tem hp2/inv2; os estaticos so mostram os dele enquanto ele (ou um inimigo que
    // o ataca / um item que ele pega) esta sendo atualizado: hpIn() troca, hpOut() devolve os do heroi 1.
    private static int hp2, inv2;
    private static boolean hpIn;
    private static int hpSavedQ, hpSavedInv;
    /** Heroi 2 esta morto (animacao de morte / esperando renascer): inimigos nao o escolhem como alvo. */
    private static boolean dead2;
    private static int deadFrames;
    /** Quadros (~20/s) ate o heroi 2 renascer perto do heroi 1 depois de morrer. */
    private static final int RESPAWN_FRAMES = 100;
    /** Troca temporaria de e.bL (alvo do inimigo) feita por pre()/post(). */
    private static boolean swapped;
    private static Object swapSaved, swapTo;
    private static Field[] heldKeys, allKeys;
    private static Method eAk, eAo, bT, bV;
    private static Object hero1, hero2;
    private static boolean failed;
    private static int frame, errors;
    private static String lastErr = "";

    private static void init() throws Exception {
        if (E != null) return;
        E = Class.forName("e");
        B = Class.forName("b");
        D = Class.forName("d");
        eBL = field(E, "bL");
        eT = field(E, "T");                       // camera X (tela = K - T)
        eU = field(E, "U");                       // camera Y (tela = L - U)
        fJ = B.getDeclaredField("j"); fJ.setAccessible(true);   // hitbox (corpo)
        fK = B.getDeclaredField("k"); fK.setAccessible(true);   // hitbox de ataque
        heldKeys = new Field[] { field(E, "df"), field(E, "di"), field(E, "dh") };
        allKeys = new Field[] { field(E, "dg"), field(E, "dh"), field(E, "di"), field(E, "dl"),
                field(E, "df"), field(E, "dk"), field(E, "dm") };
        eQ = field(E, "q");
        eR = field(E, "r");
        bBO = field(B, "bO");
        bEP = field(B, "eP");
        try { eD = field(E, "d"); } catch (Throwable t) { eD = null; }   // so a barra do P2 depende disso
        bE = method(B, "e");
        bB = B.getDeclaredMethod("b", int.class); bB.setAccessible(true);
        eDj = field(E, "dj");
        eDk = field(E, "dk");
        bBQ = field(B, "bQ");
        eAk = method(E, "ak");
        eAo = method(E, "ao");
        bT = method(B, "t");
        bV = method(B, "v");
    }

    private static Field field(Class<?> c, String n) throws Exception {
        Field f = c.getDeclaredField(n);
        f.setAccessible(true);
        return f;
    }

    private static Method method(Class<?> c, String n) throws Exception {
        Method m = c.getDeclaredMethod(n);
        m.setAccessible(true);
        return m;
    }

    private static void log(String s) {
        System.out.println("HOOK " + s);
    }

    private static void callOriginal(Method m) {
        try {
            m.invoke(null);
        } catch (InvocationTargetException ite) {
            Throwable c = ite.getCause();
            if (c instanceof RuntimeException) throw (RuntimeException) c;
            if (c instanceof Error) throw (Error) c;
            throw new RuntimeException(c);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    // ---------------------------------------------------------------- ganchos chamados pelo jogo

    public static void setHero(Object o) {
        try {
            init();
            eBL.set(null, o);
        } catch (Throwable t) {
            log("setHero: " + t);
        }
        if (o != hero1) { hero1 = o; hero2 = null; }
        if (o == null) depth = 0;
        hpIn = false;                            // o jogo reiniciou/criou heroi: ele ja acertou e.q sozinho, nao sobrescrever
        dead2 = false; deadFrames = 0;
    }

    public static void ak() {
        try { init(); } catch (Throwable t) { failed = true; status = "H2 erro init: " + t; }
        if (failed || E == null) { callOriginalSafe(true); return; }
        depth = 0;
        try {
            callOriginal(eAk);                  // heroi 1 + inimigos (pre/post escolhem o alvo de cada um)
        } finally {
            depth = 0;
            restoreBL();
            if (hpIn) { try { hpOut(true); } catch (Throwable t) { hpIn = false; } }
        }
        if (!active()) { hero2 = null; return; }
        try {
            Object h = eBL.get(null);
            if (h == null) return;
            if (h != hero1) { hero1 = h; hero2 = null; }
            if (hero2 == null) {
                hero2 = cloneHero(h);
                prevHeld = 0;
                dj2 = -1; prevPressed2 = 0; bQ2 = false; offFrames = 0;
                hp2 = eR.getInt(null); inv2 = 0;     // entra com a vida cheia
                dead2 = false; deadFrames = 0;
                log("heroi 2 criado");
                status = "Jogador 2 na partida";
            }
            // botoes do convidado -> teclas do jogo
            // taps: botoes apertados e soltos entre dois quadros (o jogo original ve esses toques em dg; antes eram perdidos)
            int tapped = Net.takeTaps() & ~SOFTKEYS;
            int held = Net.remoteBits() & ~SOFTKEYS;
            int edge = (held & ~prevHeld) | tapped;
            curReleased = prevHeld & ~held;
            prevHeld = held;
            curHeld = held | tapped;
            curPressed = (curHeld & HELD_BITS) | (edge & ~HELD_BITS);
            if (getInt(hero2, "f") == 12) {
                // heroi 2 morto: toca a animacao de morte, mas NAO deixa t() chegar ao fim dela: la o jogo chama e.a(12)
                // (fim de jogo) e o jogador 1 perderia junto. Depois de um tempo renasce perto do heroi 1.
                dead2 = true;
                if (++deadFrames > RESPAWN_FRAMES) {
                    respawnHero2();
                } else if (!((Boolean) bE.invoke(hero2))) {
                    runAs(hero2, bT, true);
                }
            } else {
                dead2 = false; deadFrames = 0;
                latchHero2();
                keepNearHero1();
                runAs(hero2, bT, true);         // atualiza o heroi 2 (com as teclas do convidado)
            }
        } catch (Throwable t) {
            error("ak", t);
        }
    }

    /** Mesma logica de e.J() para e.dj / b.bQ, mas com as teclas do convidado (e.J() so enxerga as do anfitriao). */
    private static void latchHero2() throws Exception {
        if (curReleased != 0) dj2 = -1;
        if (prevPressed2 != curPressed || prevPressed2 == 0) {
            int f = getInt(hero2, "f");
            if ((f == 5 || f == 6) && dj2 >= 0) bQ2 = dj2 <= 2;
            dj2 = -1;
        }
        if (prevPressed2 != 0) dj2++;
        prevPressed2 = curPressed;
    }

    /**
     * A camera segue so o heroi 1. Se o jogador 2 esta andando para o lado, a borda da tela vira parede invisivel;
     * se esta parado, nao e empurrado pela borda (isso "arrastava" o personagem): fica onde esta e, se a camera o
     * deixar fora da tela por ~1,5 s, reaparece ao lado do heroi 1. Tambem reaparece se cair do mapa ou ficar muito longe.
     */
    private static void keepNearHero1() throws Exception {
        int camX = eT.getInt(null), camY = eU.getInt(null);
        int k2 = getInt(hero2, "K"), l2 = getInt(hero2, "L");
        boolean lost = l2 > camY + 320 + 40 || l2 < camY - 100 || k2 < camX - 200 || k2 > camX + 440;
        if (lost) {
            placeNearHero1();
            return;
        }
        boolean outside = k2 < camX - 24 || k2 > camX + 240 + 24;
        if ((curHeld & SIDE_BITS) != 0) {
            // o jogador 2 esta andando para o lado: a borda da tela e uma parede (ele nao some da tela sem querer)
            offFrames = 0;
            int min = camX + 16, max = camX + 240 - 16;
            int c = k2 < min ? min : (k2 > max ? max : k2);
            if (c != k2) {
                setInt(hero2, "K", c);
                setInt(hero2, "a", c << 8);
                setInt(hero2, "G", 0);
            }
        } else if (outside) {
            // parado (ou sem empurrar para o lado) e a camera do heroi 1 deixou ele para tras: NAO arrasta;
            // se continuar fora da tela por ~1,5 s, reaparece ao lado do heroi 1
            if (++offFrames > OFF_WARP_FRAMES) { placeNearHero1(); }
        } else {
            offFrames = 0;
        }
    }

    /** Botoes esquerda/direita (setas e 4/6), no formato de e.Y. */
    private static final int SIDE_BITS = 4096 | 8192 | 16 | 64;
    /** Quadros (~20/s) que o heroi 2 pode ficar fora da tela, parado, antes de reaparecer ao lado do heroi 1. */
    private static final int OFF_WARP_FRAMES = 30;
    private static int offFrames;

    private static void placeNearHero1() throws Exception {
        offFrames = 0;
        int k1 = getInt(hero1, "K"), l1 = getInt(hero1, "L");
        setInt(hero2, "a", getInt(hero1, "a") + (16 << 8));
        setInt(hero2, "b", getInt(hero1, "b"));
        setInt(hero2, "K", k1 + 16);
        setInt(hero2, "L", l1);
        setInt(hero2, "G", 0);
        setInt(hero2, "H", 0);
    }

    /** Heroi 2 renasce ao lado do heroi 1 com metade da vida e um tempo de invencibilidade. */
    private static void respawnHero2() throws Exception {
        bB.invoke(hero2, 0);                     // volta ao estado "parado"
        placeNearHero1();
        int max = eR.getInt(null);
        hp2 = Math.max(1, max / 2);
        inv2 = bEP.getInt(null) * 4;
        dead2 = false; deadFrames = 0;
        prevHeld = 0; dj2 = -1; prevPressed2 = 0; bQ2 = false;
        status = "Jogador 2 voltou";
    }

    // ---------------------------------------------------------------- vida do heroi 2 (troca dos estaticos)

    private static void hpIn() throws Exception {
        if (hpIn) return;
        hpSavedQ = eQ.getInt(null);
        hpSavedInv = bBO.getInt(null);
        eQ.setInt(null, hp2);
        bBO.setInt(null, inv2);
        hpIn = true;
    }

    /** restore=true: guarda a vida do heroi 2 e devolve a do heroi 1. false: o jogo trocou de fase no meio, nao mexe. */
    private static void hpOut(boolean restore) throws Exception {
        if (!hpIn) return;
        hpIn = false;
        if (!restore) return;
        hp2 = eQ.getInt(null);
        inv2 = bBO.getInt(null);
        eQ.setInt(null, hpSavedQ);
        bBO.setInt(null, hpSavedInv);
    }

    /** Barra de vida do jogador 2, no canto superior direito. */
    private static void drawHud2() {
        try {
            if (eD == null) return;
            Object go = eD.get(null);
            if (!(go instanceof Graphics)) return;
            Graphics g = (Graphics) go;
            int max = Math.max(1, eR.getInt(null));
            int w = Math.max(20, Math.min(70, max * 61 / 60));
            int hp = Math.max(0, Math.min(max, hp2));
            int x = 240 - 6 - w, y = 6;
            g.setColor(0x000000);
            g.fillRect(x - 1, y - 1, w + 2, 8);
            g.setColor(dead2 ? 0x555555 : 0xF80000);
            g.fillRect(x, y, hp * w / max, 6);
            g.setColor(0xF0E0A0);
            g.drawRect(x - 1, y - 1, w + 1, 7);
            g.drawString(dead2 ? "P2 X" : "P2", x - 3, y - 2, Graphics.RIGHT | Graphics.TOP);
        } catch (Throwable t) {
            error("hud2", t);
        }
    }

    // ---------------------------------------------------------------- alvo dos inimigos (dano nos dois herois)

    private static boolean hits(Object hero, Object ent) throws Exception {
        int[] k = (int[]) fK.get(hero), j = (int[]) fJ.get(ent);
        return k != null && j != null && k.length >= 4 && j.length >= 4
                && k[0] < j[2] && k[2] > j[0] && k[1] < j[3] && k[3] > j[1];
    }

    private static int dist(Object hero, Object ent) throws Exception {
        return Math.abs(getInt(hero, "K") - getInt(ent, "K")) + Math.abs(getInt(hero, "L") - getInt(ent, "L"));
    }

    /** Chamado pelo jogo ANTES de atualizar cada inimigo: escolhe o heroi alvo (e.bL). */
    public static void pre(Object ent) {
        depth++;
        if (depth > 1 || swapped || hero2 == null || dead2 || ent == null || !active()) return;
        try {
            Object h1 = eBL.get(null);
            if (h1 == null || h1 != hero1) return;
            boolean a1 = hits(h1, ent), a2 = hits(hero2, ent);
            boolean use2 = (a2 && !a1) || (a1 == a2 && dist(hero2, ent) < dist(h1, ent));
            if (use2) {
                swapSaved = h1; swapTo = hero2; swapped = true;
                hpIn();                          // dano/cura deste inimigo/item vai para a vida do heroi 2
                eBL.set(null, hero2);
            }
        } catch (Throwable t) {
            error("pre", t);
        }
    }

    /** Chamado pelo jogo DEPOIS de atualizar cada inimigo: devolve e.bL ao heroi 1. */
    public static void post() {
        if (depth > 0) depth--;
        if (depth == 0) restoreBL();            // atualizacao aninhada: so o inimigo de fora devolve e.bL
    }

    private static void restoreBL() {
        if (!swapped) return;
        swapped = false;
        try {
            // se o jogo trocou o heroi no meio (nova fase), nao sobrescreve
            boolean same = eBL.get(null) == swapTo;
            if (same) eBL.set(null, swapSaved);
            hpOut(same);
        } catch (Throwable t) {
            error("post", t);
        }
        swapSaved = null; swapTo = null;
    }

    private static int getInt(Object o, String n) throws Exception {
        Field f = B.getDeclaredField(n);
        f.setAccessible(true);
        return f.getInt(o);
    }

    private static void setInt(Object o, String n, int v) throws Exception {
        Field f = B.getDeclaredField(n);
        f.setAccessible(true);
        f.setInt(o, v);
    }

    public static void ao() {
        if (failed || E == null) { callOriginalSafe(false); return; }
        callOriginal(eAo);                      // desenha a fase e o heroi 1
        if (hero2 == null || !active()) return;
        try {
            Object h = eBL.get(null);
            if (h == null || h != hero1) return;
            runAs(hero2, bV, false);            // desenha o heroi 2 por cima (desenho nao le teclas)
            drawHud2();
        } catch (Throwable t) {
            error("ao", t);
        }
    }

    private static void callOriginalSafe(boolean update) {
        try {
            init();
            callOriginal(update ? eAk : eAo);
        } catch (RuntimeException e) {
            throw e;
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    // ---------------------------------------------------------------- heroi 2

    /**
     * Roda "m" no heroi 2: troca e.bL (e, se withKeys, as teclas/e.dj/b.bQ), executa e restaura.
     * Com withKeys, tudo acontece segurando INPUT_LOCK, entao nenhuma tecla do anfitriao entra nem sai no meio.
     */
    private static void runAs(Object hero, Method m, boolean withKeys) throws Exception {
        if (!withKeys) {
            Object oldBL = eBL.get(null);
            try {
                hpIn();                                   // o heroi pisca ao ficar invencivel (b.bO): usa o do heroi 2
                eBL.set(null, hero);
                invoke(m, hero);
            } finally {
                boolean same = eBL.get(null) == hero;
                if (same) eBL.set(null, oldBL);
                hpOut(same);
            }
            return;
        }
        synchronized (INPUT_LOCK) {
            Object oldBL = eBL.get(null);
            int[] saved = new int[allKeys.length];
            for (int i = 0; i < allKeys.length; i++) saved[i] = allKeys[i].getInt(null);
            int savedDj = eDj.getInt(null);
            boolean savedBQ = bBQ.getBoolean(null);
            try {
                hpIn();                                   // vida propria: e.q / b.bO do heroi 2 enquanto ele atualiza
                eBL.set(null, hero);
                heldKeys[0].setInt(null, curHeld);        // df
                heldKeys[1].setInt(null, curPressed);     // di
                heldKeys[2].setInt(null, curPressed);     // dh
                eDk.setInt(null, curReleased);            // dk
                eDj.setInt(null, dj2);
                bBQ.setBoolean(null, bQ2);
                invoke(m, hero);
            } finally {
                dj2 = eDj.getInt(null);
                bQ2 = bBQ.getBoolean(null);
                // se o jogo trocou o heroi no meio (nova fase / reinicio), nao sobrescreve
                boolean same = eBL.get(null) == hero;
                if (same) eBL.set(null, oldBL);
                try { hpOut(same); } catch (Exception ignore) { hpIn = false; }
                for (int i = 0; i < allKeys.length; i++) allKeys[i].setInt(null, saved[i]);
                eDj.setInt(null, savedDj);
                bBQ.setBoolean(null, savedBQ);
            }
        }
    }

    private static void invoke(Method m, Object hero) throws Exception {
        try {
            m.invoke(hero);
        } catch (InvocationTargetException ite) {
            Throwable c = ite.getCause();
            throw c instanceof Exception ? (Exception) c : new RuntimeException(c);
        }
    }

    private static Object cloneHero(Object src) throws Exception {
        Constructor<?> c = B.getDeclaredConstructor();
        c.setAccessible(true);
        Object n = c.newInstance();
        copyFields(B, src, n);
        // o heroi 2 nasce um pouco a frente do heroi 1
        shift(n, "K", 40);
        shift(n, "a", 40 << 8);
        return n;
    }

    private static void shift(Object o, String name, int dx) {
        try {
            Field f = B.getDeclaredField(name);
            f.setAccessible(true);
            f.setInt(o, f.getInt(o) + dx);
        } catch (Throwable t) {
            log("shift " + name + ": " + t);
        }
    }

    private static void copyFields(Class<?> k, Object src, Object dst) {
        for (Field f : k.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            try {
                f.setAccessible(true);
                Object v = f.get(src);
                f.set(dst, copyValue(v));
            } catch (Throwable t) {
                log("campo " + f.getName() + ": " + t);
            }
        }
    }

    private static Object copyValue(Object v) throws Exception {
        if (v == null) return null;
        Class<?> k = v.getClass();
        if (k.isArray()) {
            Class<?> ct = k.getComponentType();
            if (ct.isPrimitive() && !ct.isArray()) {
                int n = Array.getLength(v);
                Object r = Array.newInstance(ct, n);
                System.arraycopy(v, 0, r, 0, n);
                return r;
            }
            return v;          // arrays de objetos / multidimensionais: compartilhados (dados)
        }
        if (k == D) {          // o sprite guarda estado de animacao por heroi: precisa de copia propria
            Constructor<?> c = D.getDeclaredConstructor();
            c.setAccessible(true);
            Object n = c.newInstance();
            copyFields(D, v, n);
            return n;
        }
        return v;
    }

    private static void error(String where, Throwable t) {
        errors++;
        String msg = where + ": " + t;
        if (!msg.equals(lastErr)) { lastErr = msg; log(msg); android.util.Log.e("SOD", "hook", t); }
        status = "H2 erro " + msg;
        if (errors > 200) { failed = true; hero2 = null; status = "H2 desligado (muitos erros): " + msg; }
    }
}
