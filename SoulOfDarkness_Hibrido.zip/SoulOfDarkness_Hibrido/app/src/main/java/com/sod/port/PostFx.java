package com.sod.port;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;

/**
 * Pos-processamento por cima do quadro do jogo (so visual, nao mexe na logica):
 *  - GRADE    : correcao de cor (mais contraste e saturacao, leve tom quente nas luzes).
 *  - BLOOM    : brilho (halo) nas partes claras: luzes, magias, lua, lava, olhos.
 *  - VIGNETTE : escurece os cantos para dar clima.
 *  - EMBERS   : faiscas/poeira flutuando; a cor acompanha as cores claras da cena.
 * Tudo e ligado/desligado pelas constantes abaixo. Se o aparelho for lento, o bloom e as faiscas
 * desligam sozinhos (ver 'slow').
 *
 * Desempenho: buildGlow() (CPU, barato) roda UMA vez por quadro do jogo (~20 Hz) e guarda o halo em pequenos
 * bitmaps (Glow). drawScene()/drawOverlay() so desenham, e rodam a cada vsync (60 Hz) na GPU.
 */
final class PostFx {
    static final boolean ENABLED = true;
    static final boolean GRADE = true, BLOOM = true, VIGNETTE = true, EMBERS = true;

    /** Brilho: acima de que luminosidade (0..1) a cor entra no halo, e o quanto (0..1) ele soma na tela. */
    static final float BLOOM_THRESHOLD = 0.66f, BLOOM_GAIN = 1.5f;
    static final int BLOOM_ALPHA_WIDE = 97, BLOOM_ALPHA_TIGHT = 77;
    /** Vinheta: escurecimento maximo nos cantos (0..1). */
    static final float VIGNETTE_STRENGTH = 0.42f;
    static final int EMBER_COUNT = 40;

    private static final int LW = 240, LH = 320;   // = Display.WIDTH/HEIGHT (resolucao logica do jogo)

    private final Paint gradePaint = new Paint();
    private final Paint brightPaint = new Paint();
    private final Paint blurPaint = new Paint();
    private final Paint glowWide = new Paint(), glowTight = new Paint();
    private final Paint vigPaint = new Paint();
    private final Paint emberPaint = new Paint(), emberHalo = new Paint();

    /** Halo pronto (120x160 e 60x80) de um quadro. Cada quadro publicado tem o seu: a GPU le enquanto o jogo escreve o proximo. */
    static final class Glow {
        final Bitmap b2 = Bitmap.createBitmap(LW / 2, LH / 2, Bitmap.Config.ARGB_8888);   // 120x160
        final Bitmap b3 = Bitmap.createBitmap(LW / 4, LH / 4, Bitmap.Config.ARGB_8888);   // 60x80
        final Canvas c2 = new Canvas(b2), c3 = new Canvas(b3);
        boolean valid;
    }

    private final Bitmap b1 = Bitmap.createBitmap(LW, LH, Bitmap.Config.ARGB_8888);            // 240x320 (so as luzes), temporario
    private final Canvas c1 = new Canvas(b1);
    private final Rect r1 = new Rect(0, 0, LW, LH), r2 = new Rect(0, 0, LW / 2, LH / 2), r3 = new Rect(0, 0, LW / 4, LH / 4);
    private final int[] sample = new int[(LW / 4) * (LH / 4)];

    private Bitmap vig;
    private final Rect vigSrc = new Rect();

    // faiscas (coordenadas logicas 240x320)
    private final float[] ex = new float[EMBER_COUNT], ey = new float[EMBER_COUNT];
    private final float[] evx = new float[EMBER_COUNT], evy = new float[EMBER_COUNT];
    private final float[] esz = new float[EMBER_COUNT], eph = new float[EMBER_COUNT];
    private long lastMs;
    private int tintR = 255, tintG = 170, tintB = 80;
    private int frameNo;
    private final java.util.Random rnd = new java.util.Random(7);

    // protecao para aparelho lento
    private volatile boolean slow;
    private float costEma;      // ms gastos pelo bloom, media movel
    private int slowFrames;

    PostFx() {
        // cor
        ColorMatrix sat = new ColorMatrix();
        sat.setSaturation(1.16f);
        float k = 1.10f, t = 128f * (1f - k);              // contraste em torno do cinza medio
        ColorMatrix con = new ColorMatrix(new float[] {
            k * 1.035f, 0, 0, 0, t,
            0, k * 1.00f, 0, 0, t,
            0, 0, k * 0.975f, 0, t,
            0, 0, 0, 1, 0 });                                // R um pouco acima e B abaixo: tom quente
        sat.postConcat(con);
        gradePaint.setFilterBitmap(true);
        if (GRADE) gradePaint.setColorFilter(new ColorMatrixColorFilter(sat));

        // passo "so o que e claro": (cor - limiar) * ganho
        float g = BLOOM_GAIN, off = -255f * BLOOM_THRESHOLD * g;
        brightPaint.setFilterBitmap(true);
        brightPaint.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[] {
            g, 0, 0, 0, off,
            0, g, 0, 0, off,
            0, 0, g, 0, off,
            0, 0, 0, 1, 0 })));
        blurPaint.setFilterBitmap(true);

        PorterDuffXfermode screen = new PorterDuffXfermode(PorterDuff.Mode.SCREEN);
        glowWide.setFilterBitmap(true); glowWide.setXfermode(screen); glowWide.setAlpha(BLOOM_ALPHA_WIDE);
        glowTight.setFilterBitmap(true); glowTight.setXfermode(screen); glowTight.setAlpha(BLOOM_ALPHA_TIGHT);
        vigPaint.setFilterBitmap(true);
        emberPaint.setAntiAlias(true); emberPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        emberHalo.setAntiAlias(true); emberHalo.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));

        for (int i = 0; i < EMBER_COUNT; i++) respawn(i, true);
    }

    // ------------------------------------------------------------------ cena (le o quadro)

    /** Calcula o halo do quadro 'src' (regiao 'from', ou tudo se null) dentro de 'g'. Barato: ~1-2 ms. */
    synchronized void buildGlow(Bitmap src, Rect from, Glow g) {
        g.valid = false;
        if (!ENABLED || !BLOOM || slow) return;
        long t0 = System.nanoTime();
        // quadro -> 240x320 (so luzes) -> 120x160 -> 60x80: cada passo de 2x com filtro = media 2x2
        c1.drawBitmap(src, from, r1, brightPaint);
        g.c2.drawBitmap(b1, r1, r2, blurPaint);
        g.c3.drawBitmap(g.b2, r2, r3, blurPaint);
        g.valid = true;
        float ms = (System.nanoTime() - t0) / 1e6f;
        costEma = costEma == 0 ? ms : costEma * 0.95f + ms * 0.05f;
        if (costEma > 14f) { if (++slowFrames > 90) slow = true; } else slowFrames = 0;
    }

    /** Desenha o quadro com a cor ajustada e o brilho (halo ja calculado em 'g', pode ser null). Roda na thread de video. */
    void drawScene(Canvas cv, Bitmap src, Rect from, Rect dst, Paint plain, Glow g) {
        if (!ENABLED) { cv.drawBitmap(src, from, dst, plain); return; }
        cv.drawBitmap(src, from, dst, GRADE ? gradePaint : plain);
        if (g == null || !g.valid || !BLOOM || slow) return;
        cv.drawBitmap(g.b2, r2, dst, glowTight);
        cv.drawBitmap(g.b3, r3, dst, glowWide);
    }

    // ------------------------------------------------------------------ sobre a cena

    /** Vinheta + faiscas, por cima de tudo que e do jogo (antes dos botoes). */
    void drawOverlay(Canvas cv, Rect dst, Glow g) {
        if (!ENABLED) return;
        cv.save();
        cv.clipRect(dst);                       // faiscas nao vazam para fora da tela do jogo
        if (VIGNETTE) {
            if (vig == null) buildVignette();
            cv.drawBitmap(vig, vigSrc, dst, vigPaint);
        }
        if (EMBERS && !slow) drawEmbers(cv, dst, g);
        cv.restore();
    }

    private void buildVignette() {
        int w = 96, h = 128;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float dx = (x + 0.5f) / w * 2f - 1f, dy = (y + 0.5f) / h * 2f - 1f;
                float d = (float) Math.sqrt(dx * dx * 0.8f + dy * dy * 0.8f);   // 0 centro .. ~1.13 canto
                float v = (d - 0.55f) / 0.6f;
                v = v < 0 ? 0 : (v > 1 ? 1 : v);
                v = v * v * (3f - 2f * v);                                      // smoothstep
                px[y * w + x] = ((int) (v * VIGNETTE_STRENGTH * 255f) << 24);   // preto com alpha
            }
        }
        vig = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        vigSrc.set(0, 0, w, h);
    }

    private void respawn(int i, boolean anywhere) {
        ex[i] = rnd.nextFloat() * LW;
        ey[i] = anywhere ? rnd.nextFloat() * LH : LH + 4f + rnd.nextFloat() * 20f;
        evx[i] = (rnd.nextFloat() - 0.5f) * 6f;          // px logicos por segundo
        evy[i] = -(5f + rnd.nextFloat() * 14f);          // sobe
        esz[i] = 0.5f + rnd.nextFloat() * 1.1f;
        eph[i] = rnd.nextFloat() * 6.283f;
    }

    private void drawEmbers(Canvas cv, Rect dst, Glow g) {
        long now = System.currentTimeMillis();
        float dt = lastMs == 0 ? 0.033f : Math.min(0.05f, (now - lastMs) / 1000f);
        lastMs = now;
        if ((frameNo++ & 63) == 0 && g != null && g.valid) updateTint(g);
        float sx = dst.width() / (float) LW, sy = dst.height() / (float) LH;
        for (int i = 0; i < EMBER_COUNT; i++) {
            eph[i] += dt * 3f;
            ex[i] += (evx[i] + (float) Math.sin(eph[i]) * 5f) * dt;
            ey[i] += evy[i] * dt;
            if (ey[i] < -4f || ex[i] < -4f || ex[i] > LW + 4f) { respawn(i, false); continue; }
            float fade = 0.55f + 0.45f * (float) Math.sin(eph[i] * 1.7f);        // cintila
            float edge = Math.min(1f, Math.min(ey[i], LH - ey[i]) / 40f);         // some nas bordas de cima/baixo
            if (edge <= 0) continue;
            float a = fade * edge;
            float px = dst.left + ex[i] * sx, py = dst.top + ey[i] * sy, r = esz[i] * sx;
            emberHalo.setColor(argb((int) (38 * a), tintR, tintG, tintB));
            cv.drawCircle(px, py, r * 3.2f, emberHalo);
            emberPaint.setColor(argb((int) (230 * a), Math.min(255, tintR + 40), Math.min(255, tintG + 40), Math.min(255, tintB + 40)));
            cv.drawCircle(px, py, r, emberPaint);
        }
    }

    /** Cor das faiscas = media das partes claras da cena (lava -> laranja, noite -> azul palido), com um fundo quente. */
    private void updateTint(Glow gl) {
        gl.b3.getPixels(sample, 0, gl.b3.getWidth(), 0, 0, gl.b3.getWidth(), gl.b3.getHeight());
        long r = 0, g = 0, b = 0;
        for (int p : sample) { r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; }
        int n = sample.length;
        float ar = r / (float) n, ag = g / (float) n, ab = b / (float) n;
        float m = Math.max(ar, Math.max(ag, ab));
        if (m < 6f) { tintR = 255; tintG = 170; tintB = 80; return; }          // cena escura: quente padrao
        float k = 255f / m;
        float mix = Math.min(1f, m / 40f) * 0.65f;                              // quanto confiar na cena
        tintR = (int) (255 * (1 - mix) + ar * k * mix);
        tintG = (int) (170 * (1 - mix) + ag * k * mix);
        tintB = (int) (80 * (1 - mix) + ab * k * mix);
    }

    private static int argb(int a, int r, int g, int b) {
        a = a < 0 ? 0 : (a > 255 ? 255 : a);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
