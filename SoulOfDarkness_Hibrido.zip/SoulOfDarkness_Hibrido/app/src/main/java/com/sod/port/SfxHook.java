package com.sod.port;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.SoundPool;

/**
 * Efeitos sonoros do Kale vindos da versao DSi (assets/sfx/*.ogg). O PatchSfx insere
 * SfxHook.play(id) no codigo do heroi (b.class): 0 pulo, 1 ataque, 2 dano, 3 morte.
 */
public final class SfxHook {
    private static final String[] FILES = { "JUMP", "ICE_WHIP", "HURT", "HERO_DEAD" };
    private static final long[] MIN_GAP_MS = { 180, 220, 400, 1500 };   // evita som repetido no mesmo instante
    private static SoundPool pool;
    private static final int[] ids = new int[FILES.length];
    private static final boolean[] ready = new boolean[FILES.length];
    private static final long[] last = new long[FILES.length];

    private SfxHook() { }

    public static synchronized void init(Context c) {
        if (pool != null) return;
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                @Override public void onLoadComplete(SoundPool sp, int sampleId, int status) {
                    if (status != 0) return;
                    for (int i = 0; i < ids.length; i++) if (ids[i] == sampleId) ready[i] = true;
                }
            });
            for (int i = 0; i < FILES.length; i++) {
                AssetFileDescriptor afd = c.getAssets().openFd("sfx/" + FILES[i] + ".ogg");
                try { ids[i] = pool.load(afd, 1); } finally { afd.close(); }
            }
        } catch (Throwable t) {
            System.out.println("SOD SfxHook.init: " + t);
        }
    }

    /** Chamado pelo jogo (codigo patchado). Nunca lanca excecao. */
    public static void play(int id) {
        try {
            if (pool == null || id < 0 || id >= FILES.length || !ready[id]) return;
            long now = System.currentTimeMillis();
            if (now - last[id] < MIN_GAP_MS[id]) return;
            last[id] = now;
            pool.play(ids[id], 1f, 1f, 1, 0, 1f);
        } catch (Throwable ignore) { }
    }
}
