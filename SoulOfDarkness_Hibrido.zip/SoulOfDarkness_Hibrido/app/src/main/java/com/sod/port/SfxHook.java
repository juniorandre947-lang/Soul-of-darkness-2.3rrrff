package com.sod.port;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 * Efeitos sonoros da versao DSi (assets/sfx/*.ogg, renderizados do SoD.sdat por tools/sdat/).
 * assets/sfx/index.txt: NOME|arquivo1,arquivo2|jitter|loop
 *  - varios arquivos = variantes que o jogo original sorteia (ex.: SFX_HIT);
 *  - jitter = o original varia o pitch +-1 semitom a cada toque (aplicado aqui pela taxa de reproducao);
 *  - loop = som sustentado (laser, porta, elevador, medidor).
 * Ids 0..3 sao os ganchos que o PatchSfx ja insere em b.class: 0 pulo, 1 chicote, 2 dano, 3 morte.
 * Outros efeitos: SfxHook.play("SFX_NOME"). Nunca lanca excecao.
 */
public final class SfxHook {
    private static final class Fx {
        String name; int[] ids; boolean[] ready; boolean jitter, loop; long last; int lastVar = -1;
    }
    private static final ArrayList<Fx> list = new ArrayList<Fx>();
    private static final HashMap<String, Integer> byName = new HashMap<String, Integer>();
    private static final HashMap<Integer, Fx> bySample = new HashMap<Integer, Fx>();
    private static final long MIN_GAP_MS = 120;          // evita o mesmo som disparado varias vezes no mesmo instante
    private static final Random rnd = new Random();
    private static SoundPool pool;

    private SfxHook() { }

    public static synchronized void init(Context c) {
        if (pool != null) return;
        try {
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            pool = new SoundPool.Builder().setMaxStreams(10).setAudioAttributes(aa).build();
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                @Override public void onLoadComplete(SoundPool sp, int sampleId, int status) {
                    if (status != 0) return;
                    Fx f = bySample.get(sampleId);
                    if (f == null) return;
                    for (int i = 0; i < f.ids.length; i++) if (f.ids[i] == sampleId) f.ready[i] = true;
                }
            });
            InputStream in = c.getAssets().open("sfx/index.txt");
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.trim().split("\\|");
                if (p.length < 4) continue;
                Fx f = new Fx();
                f.name = p[0];
                String[] files = p[1].split(",");
                f.jitter = "1".equals(p[2]);
                f.loop = "1".equals(p[3]);
                f.ids = new int[files.length];
                f.ready = new boolean[files.length];
                for (int i = 0; i < files.length; i++) {
                    AssetFileDescriptor afd = c.getAssets().openFd("sfx/" + files[i] + ".ogg");
                    try { f.ids[i] = pool.load(afd, 1); } finally { afd.close(); }
                    bySample.put(f.ids[i], f);
                }
                byName.put(f.name, list.size());
                list.add(f);
            }
            r.close();
        } catch (Throwable t) {
            System.out.println("SOD SfxHook.init: " + t);
        }
    }

    /** Chamado pelo codigo patchado do jogo (0 pulo, 1 chicote, 2 dano, 3 morte). */
    public static void play(int id) {
        try {
            if (id < 0 || id >= list.size()) return;
            fire(list.get(id));
        } catch (Throwable ignore) { }
    }

    /** Toca pelo nome, ex.: play("SFX_HIT"). */
    public static void play(String name) {
        try {
            Integer i = byName.get(name);
            if (i != null) fire(list.get(i));
        } catch (Throwable ignore) { }
    }

    private static void fire(Fx f) {
        if (pool == null) return;
        long now = System.currentTimeMillis();
        if (now - f.last < MIN_GAP_MS) return;
        int v = f.ids.length == 1 ? 0 : rnd.nextInt(f.ids.length);
        if (f.ids.length > 1 && v == f.lastVar) v = (v + 1) % f.ids.length;    // nao repete a mesma variante em seguida
        if (!f.ready[v]) return;
        f.last = now; f.lastVar = v;
        float rate = 1f;
        if (f.jitter) rate = (float) Math.pow(2.0, (rnd.nextDouble() * 2 - 1) / 12.0);   // +-1 semitom, como no DS
        pool.play(f.ids[v], 1f, 1f, 1, f.loop ? -1 : 0, rate);
    }
}
