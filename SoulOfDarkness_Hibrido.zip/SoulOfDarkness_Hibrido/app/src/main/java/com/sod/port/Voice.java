package com.sod.port;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.Build;
import android.widget.Toast;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Chat de voz do multiplayer (anfitriao <-> convidado), pela mesma conexao TCP do jogo.
 *  - Captura 8 kHz mono, quadros de 20 ms, comprimidos em mu-law (160 bytes cada, ~64 kbps).
 *  - So envia enquanto voce fala (deteccao de voz com piso de ruido adaptativo): economiza rede e tira o chiado.
 *  - Usa VOICE_COMMUNICATION + cancelador de eco / supressor de ruido do Android quando o aparelho tem.
 *    Mesmo assim, o ideal e usar fones de ouvido (sem fone, o alto-falante pode "voltar" no microfone do outro).
 *  - O microfone so fica aberto enquanto estiver ligado (botao MIC) e conectado.
 */
final class Voice {
    private Voice() { }

    static final int RATE = 8000, FRAME = 160;          // 20 ms
    private static final int REQ = 77;

    private static Activity act;
    private static volatile boolean micOn = true, running;
    private static volatile int gen;
    private static volatile long lastSent, lastRemote;
    private static final LinkedBlockingQueue<byte[]> playQ = new LinkedBlockingQueue<byte[]>(100);

    // ------------------------------------------------------------ estado / permissao

    static void init(Activity a) { act = a; }

    static boolean micOn() { return micOn; }
    /** Eu estou falando agora (para o botao ficar verde). */
    static boolean talking() { return micOn && System.currentTimeMillis() - lastSent < 400; }
    /** O outro jogador esta falando agora. */
    static boolean remoteTalking() { return System.currentTimeMillis() - lastRemote < 400; }

    static boolean hasPermission() {
        if (act == null) return false;
        if (Build.VERSION.SDK_INT < 23) return true;
        return act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    /** Pede a permissao do microfone (se faltar). Chamar na thread da interface. */
    static void ensurePermission() {
        if (act != null && Build.VERSION.SDK_INT >= 23 && !hasPermission()) {
            act.requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, REQ);
        }
    }

    static void onPermissionResult(int requestCode, int[] results) {
        if (requestCode != REQ || act == null) return;
        boolean ok = results != null && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        Toast.makeText(act, ok ? "Microfone liberado" : "Sem permissão do microfone: você só vai ouvir o outro jogador",
                Toast.LENGTH_LONG).show();
    }

    /** Botao MIC. */
    static void toggleMic() {
        micOn = !micOn;
        if (micOn) ensurePermission();
    }

    // ------------------------------------------------------------ ciclo de vida (chamado por Net)

    static synchronized void start() {
        if (running) return;
        running = true;
        final int g = ++gen;
        playQ.clear();
        Thread p = new Thread(new Runnable() { @Override public void run() { playLoop(g); } }, "voice-play");
        Thread c = new Thread(new Runnable() { @Override public void run() { captureLoop(g); } }, "voice-cap");
        p.setDaemon(true); c.setDaemon(true);
        p.start(); c.start();
    }

    static synchronized void stop() {
        running = false;
        gen++;
        playQ.clear();
    }

    private static boolean alive(int g) { return running && gen == g; }

    /** Quadro de voz recebido do outro jogador (thread de rede). */
    static void onRemote(byte[] ulaw) {
        lastRemote = System.currentTimeMillis();
        if (!playQ.offer(ulaw)) { playQ.poll(); playQ.offer(ulaw); }
    }

    // ------------------------------------------------------------ reproducao

    private static void playLoop(int g) {
        AudioTrack t = null;
        try {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int buf = Math.max(min, FRAME * 2 * 6);
            t = new AudioTrack(
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                    new AudioFormat.Builder().setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build(),
                    buf, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE);
            t.play();
            short[] pcm = new short[FRAME];
            while (alive(g)) {
                byte[] f = playQ.poll(100, TimeUnit.MILLISECONDS);
                if (f == null) continue;
                while (playQ.size() > 8) f = playQ.poll();      // atrasou (rede): descarta o velho, mantem a conversa em tempo real
                if (f == null) continue;
                int n = Math.min(f.length, pcm.length);
                for (int i = 0; i < n; i++) pcm[i] = Ulaw.decode(f[i]);
                t.write(pcm, 0, n);
            }
        } catch (Throwable e) {
            Hook.status = "Voz (alto-falante): " + e;
        } finally {
            if (t != null) { try { t.stop(); } catch (Throwable ignore) { } try { t.release(); } catch (Throwable ignore) { } }
        }
    }

    // ------------------------------------------------------------ captura

    private static final class Rec {
        AudioRecord r; AcousticEchoCanceler aec; NoiseSuppressor ns;
        void release() {
            try { if (aec != null) aec.release(); } catch (Throwable ignore) { }
            try { if (ns != null) ns.release(); } catch (Throwable ignore) { }
            try { r.stop(); } catch (Throwable ignore) { }
            try { r.release(); } catch (Throwable ignore) { }
        }
    }

    private static Rec open() {
        int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int[] sources = { MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.MIC };
        for (int src : sources) {
            try {
                AudioRecord r = new AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, FRAME * 2 * 8));
                if (r.getState() != AudioRecord.STATE_INITIALIZED) { r.release(); continue; }
                Rec x = new Rec();
                x.r = r;
                try {
                    if (AcousticEchoCanceler.isAvailable()) {
                        x.aec = AcousticEchoCanceler.create(r.getAudioSessionId());
                        if (x.aec != null) x.aec.setEnabled(true);
                    }
                } catch (Throwable ignore) { }
                try {
                    if (NoiseSuppressor.isAvailable()) {
                        x.ns = NoiseSuppressor.create(r.getAudioSessionId());
                        if (x.ns != null) x.ns.setEnabled(true);
                    }
                } catch (Throwable ignore) { }
                r.startRecording();
                return x;
            } catch (Throwable ignore) { }
        }
        return null;
    }

    private static void captureLoop(int g) {
        Rec rec = null;
        long retryAt = 0;
        short[] pcm = new short[FRAME];
        double noise = 150;                                    // piso de ruido estimado
        int hang = 0;                                          // quadros extras enviados depois da fala (evita cortar final de palavra)
        try {
            while (alive(g)) {
                boolean want = micOn && hasPermission() && Net.connected();
                if (!want) {
                    if (rec != null) { rec.release(); rec = null; }       // microfone fechado quando mudo / desconectado
                    Thread.sleep(150);
                    continue;
                }
                if (rec == null) {
                    if (System.currentTimeMillis() < retryAt) { Thread.sleep(100); continue; }
                    rec = open();
                    if (rec == null) { retryAt = System.currentTimeMillis() + 1500; continue; }
                }
                int got = 0;
                while (got < FRAME && alive(g)) {
                    int n = rec.r.read(pcm, got, FRAME - got);
                    if (n <= 0) break;
                    got += n;
                }
                if (got < FRAME) {                                         // erro de leitura: reabre
                    rec.release(); rec = null;
                    retryAt = System.currentTimeMillis() + 500;
                    continue;
                }
                double sum = 0;
                for (int i = 0; i < FRAME; i++) sum += (double) pcm[i] * pcm[i];
                double rms = Math.sqrt(sum / FRAME);
                double thr = Math.max(350, noise * 3);
                if (rms > thr) hang = 15;
                else {
                    noise = noise * 0.97 + rms * 0.03;
                    if (hang > 0) hang--;
                }
                if (hang > 0) {
                    byte[] out = new byte[FRAME];
                    for (int i = 0; i < FRAME; i++) out[i] = Ulaw.encode(pcm[i]);
                    lastSent = System.currentTimeMillis();
                    Net.sendVoice(out);
                }
            }
        } catch (Throwable e) {
            Hook.status = "Voz (microfone): " + e;
        } finally {
            if (rec != null) rec.release();
        }
    }
}
