package com.sod.port;

/** Codec G.711 mu-law: 16 bits -> 8 bits (metade do tamanho, qualidade de telefone). Java puro. */
final class Ulaw {
    private Ulaw() { }

    static byte encode(short pcm) {
        int s = pcm;
        int sign = (s >> 8) & 0x80;
        if (sign != 0) s = -s;
        if (s > 32635) s = 32635;
        s += 0x84;
        int exp = 7;
        for (int mask = 0x4000; (s & mask) == 0 && exp > 0; exp--, mask >>= 1) { }
        int mant = (s >> (exp + 3)) & 0x0F;
        return (byte) ~(sign | (exp << 4) | mant);
    }

    static short decode(byte u) {
        int v = ~u & 0xFF;
        int sign = v & 0x80, exp = (v >> 4) & 7, mant = v & 0x0F;
        int t = ((mant << 3) + 0x84) << exp;
        return (short) (sign != 0 ? (0x84 - t) : (t - 0x84));
    }
}
