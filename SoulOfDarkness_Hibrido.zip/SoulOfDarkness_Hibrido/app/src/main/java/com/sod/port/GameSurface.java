package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Superficie que mostra o quadro 240x320 do jogo (escalado) e os controles na tela. */
public class GameSurface extends SurfaceView implements SurfaceHolder.Callback, Display.Host, Controls.KeySink, Net.Source {
    /** Fator HD (ver HdPack): o quadro e SxS vezes maior que 240x320, mas o jogo continua em coordenadas 240x320. */
    private static final int S = HdPack.SCALE;
    /** true = escala suavizada; false = pixels nitidos. Em HD a reducao final para a tela precisa de filtro. */
    private static final boolean SMOOTH = S > 1;

    /** Onde o jogo pinta (240x320 logicos * S). So a thread do jogo escreve aqui. */
    private final Bitmap frame = Bitmap.createBitmap(Display.WIDTH * S, Display.HEIGHT * S, Bitmap.Config.ARGB_8888);
    private final Graphics fg = new Graphics(frame, S);
    private final PostFx fx = new PostFx();   // cor, brilho, vinheta e faiscas (ver PostFx.java)
    private final Object lock = new Object();
    private final Paint blit = new Paint();
    private final Paint copyPaint = new Paint();
    private final Rect srcR = new Rect(0, 0, Display.WIDTH * S, Display.HEIGHT * S);
    private final Rect dstR = new Rect();

    /**
     * Quadro pronto para a tela. O jogo pinta em 'frame' (~20 quadros/s, ritmo original do J2ME) e, ao terminar,
     * copia para um destes dois (alternando); a thread de video desenha o mais recente a cada vsync (60 Hz) pela
     * GPU. Assim o jogo nunca espera a tela, e a tela nunca le um quadro pela metade.
     */
    private static final class Snap {
        final Bitmap img = Bitmap.createBitmap(Display.WIDTH * S, Display.HEIGHT * S, Bitmap.Config.ARGB_8888);
        final android.graphics.Canvas c = new android.graphics.Canvas(img);
        final PostFx.Glow glow = new PostFx.Glow();
    }
    private final Snap[] snaps = { new Snap(), new Snap() };
    private int backIdx;
    private volatile Snap front;
    private Bitmap guestSrc;                                  // multiplayer (convidado): quadro recebido que ja tem halo
    private final PostFx.Glow guestGlow = new PostFx.Glow();

    private volatile Renderer renderer;
    /** Alvo de apresentacao: 60 quadros/s (em tela de 90/120 Hz nao adianta gastar mais). */
    private static final long FRAME_NS = 1000000000L / 60L;
    private volatile boolean useHwCanvas = android.os.Build.VERSION.SDK_INT >= 26;
    private Thread prioThread;
    private int drawErrors;
    private final Controls controls = new Controls();
    private volatile boolean ready;
    private volatile int paints;
    private final long startMs = System.currentTimeMillis();
    private volatile String dbgText = "";
    private volatile boolean dbgShow = true;
    private boolean dbgThreadOn;
    /** Painel de diagnostico (texto no topo da tela). Ponha false depois que tudo funcionar. */
    static final boolean DEBUG = false;

    public GameSurface(Context ctx) {
        super(ctx);
        blit.setFilterBitmap(SMOOTH);
        copyPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        getHolder().addCallback(this);
        setFocusable(true);
    }

    // ---- Display.Host: chamado pela thread do jogo ----
    private volatile String errText;
    private final Paint errPaint = new Paint();

    /** Registra um erro (aparece em vermelho na tela e no Logcat, filtro SOD). */
    public void showError(String where, Throwable t) {
        android.util.Log.e("SOD", where, t);
        StringBuilder sb = new StringBuilder(where).append(": ").append(t);
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; i < st.length && i < 6; i++) sb.append("\n  ").append(st[i]);
        if (t.getCause() != null) sb.append("\nCausa: ").append(t.getCause());
        errText = sb.toString();
    }

    @Override public void repaint(Canvas c) {
        Thread me = Thread.currentThread();
        if (prioThread != me) {            // a thread do jogo ganha prioridade de video (so uma vez)
            prioThread = me;
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY); } catch (Throwable ignore) { }
        }
        try {
            synchronized (lock) {
                fg.resetClip();
                c.__paint(fg);
                publish();
            }
            paints++;
        } catch (Throwable t) {
            showError("paint()", t);
            return;
        }
        String e = errText;
        if (e != null && e.startsWith("paint()")) errText = null; // erro de um quadro isolado some no proximo quadro bom
    }

    /** Copia o quadro recem-pintado para o proximo Snap e calcula o halo (barato). Chamar com 'lock' preso. */
    private void publish() {
        Snap back = snaps[backIdx];
        back.c.drawBitmap(frame, 0f, 0f, copyPaint);
        fx.buildGlow(frame, srcR, back.glow);
        front = back;
        backIdx ^= 1;
    }

    private String buildDebug() {
        StringBuilder sb = new StringBuilder();
        Canvas cc = Display.currentCanvas();
        int nonBlack = 0, total = 0;
        synchronized (lock) {
            for (int y = 4; y < Display.HEIGHT; y += 8)
                for (int x = 4; x < Display.WIDTH; x += 8) {
                    total++;
                    if ((frame.getPixel(x * S, y * S) & 0xFFFFFF) != 0) nonBlack++;
                }
        }
        dbgShow = nonBlack == 0 || errText != null; // some quando o jogo ja aparece na tela
        sb.append("t=").append((System.currentTimeMillis() - startMs) / 1000).append("s paints=").append(paints)
          .append(" canvas=").append(cc == null ? "NULL" : cc.getClass().getName())
          .append(" naoPreto=").append(nonBlack).append('/').append(total).append('\n');
        for (java.util.Map.Entry<Thread, StackTraceElement[]> e : Thread.getAllStackTraces().entrySet()) {
            StackTraceElement[] st = e.getValue();
            String game = null;
            for (StackTraceElement f : st) {
                String c = f.getClassName();
                if (c.length() <= 2 || c.startsWith("Gloft")) { game = f.toString(); break; }
            }
            if (game == null) continue;
            sb.append("[").append(e.getKey().getName()).append(" ").append(e.getKey().getState()).append("] ")
              .append(game);
            if (st.length > 0) sb.append(" <- ").append(st[0]);
            sb.append('\n');
        }
        sb.append("--- PRIMEIRAS LINHAS ---\n");
        for (String l : DebugLog.head(18)) sb.append("> ").append(l).append('\n');
        sb.append("--- ULTIMAS ---\n");
        for (String l : DebugLog.last(6)) sb.append("> ").append(l).append('\n');
        return sb.toString();
    }

    private void startDebugThread() {
        if (!DEBUG || dbgThreadOn) return;
        dbgThreadOn = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
                    try { dbgText = buildDebug(); } catch (Throwable ignore) { }
                }
            }
        }, "dbg-refresh");
        t.setDaemon(true);
        t.start();
    }

    private void drawStatus(android.graphics.Canvas cv) {
        String st = Hook.status;
        if (st == null) return;
        errPaint.setTextSize(cv.getWidth() / 70f);
        errPaint.setColor(Color.argb(170, 0, 0, 0));
        cv.drawRect(0, 0, errPaint.measureText(st) + 16f, errPaint.getTextSize() * 1.6f, errPaint);
        errPaint.setColor(Color.YELLOW);
        cv.drawText(st, 8f, errPaint.getTextSize() * 1.2f, errPaint);
    }

    private void drawDebug(android.graphics.Canvas cv) {
        if (!DEBUG || !dbgShow) return;
        String e = dbgText;
        if (e.length() == 0) return;
        float ts = cv.getWidth() / 46f;
        errPaint.setTextSize(ts);
        float y = cv.getHeight() * 0.03f;
        errPaint.setColor(Color.argb(200, 0, 0, 0));
        cv.drawRect(0, 0, cv.getWidth(), cv.getHeight() * 0.64f, errPaint);
        errPaint.setColor(Color.rgb(120, 255, 120));
        float limit = cv.getHeight() * 0.64f;
        for (String line : e.split("\n")) {
            while (line.length() > 0 && y < limit) {
                int n = errPaint.breakText(line, true, cv.getWidth() - 20f, null);
                if (n <= 0) break;
                cv.drawText(line.substring(0, n), 10f, y, errPaint);
                y += ts * 1.15f;
                line = line.substring(n);
            }
        }
    }

    private void drawError(android.graphics.Canvas cv) {
        String e = errText;
        if (e == null) return;
        errPaint.setColor(Color.argb(210, 0, 0, 0));
        cv.drawRect(0, 0, cv.getWidth(), cv.getHeight() * 0.6f, errPaint);
        errPaint.setColor(Color.rgb(255, 80, 80));
        errPaint.setTextSize(cv.getWidth() / 36f);
        float y = errPaint.getTextSize() * 1.5f;
        for (String line : e.split("\n")) {
            while (line.length() > 0) {
                int n = errPaint.breakText(line, true, cv.getWidth() - 20f, null);
                if (n <= 0) break;
                cv.drawText(line.substring(0, n), 10f, y, errPaint);
                y += errPaint.getTextSize() * 1.2f;
                line = line.substring(n);
            }
        }
    }

    /** Thread de video: redesenha a cada vsync (60 Hz) o quadro mais recente + efeitos + controles. */
    private final class Renderer extends Thread {
        volatile boolean running = true;
        Renderer() { super("sod-render"); }

        @Override public void run() {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY); } catch (Throwable ignore) { }
            long next = System.nanoTime();
            while (running) {
                boolean ok = drawFrame();
                if (!ok) { pause(8000000L); continue; }
                long now = System.nanoTime();
                next += FRAME_NS;
                if (next < now - FRAME_NS) next = now;            // atrasou: nao tenta recuperar
                long wait = next - now;
                if (wait > 1000000L) pause(wait - 500000L);       // tela de 90/120 Hz: limita a ~60
            }
        }

        private void pause(long ns) {
            try { Thread.sleep(ns / 1000000L, (int) (ns % 1000000L)); } catch (InterruptedException e) { running = false; }
        }
    }

    private android.graphics.Canvas lockCanvasCompat(SurfaceHolder h) {
        if (useHwCanvas) {
            try { return h.lockHardwareCanvas(); }                // GPU: escala, cor, brilho e vinheta saem de graca
            catch (Throwable t) { useHwCanvas = false; }          // alguns aparelhos recusam: cai para o desenho por CPU
        }
        return h.lockCanvas();
    }

    /** Desenha um quadro na tela. false = nao havia superficie. */
    private boolean drawFrame() {
        SurfaceHolder h = getHolder();
        android.graphics.Canvas cv = null;
        try {
            cv = lockCanvasCompat(h);
            if (cv == null) return false;
            cv.drawColor(Color.BLACK);
            controls.copyGameRect(dstR);
            if (Net.role == Net.GUEST) {
                Bitmap gf = Net.guestFrame();
                if (gf != null) {
                    if (gf != guestSrc) { guestSrc = gf; fx.buildGlow(gf, null, guestGlow); }
                    fx.drawScene(cv, gf, null, dstR, blit, guestGlow);
                    fx.drawOverlay(cv, dstR, guestGlow);
                }
            } else {
                Snap f = front;
                if (f != null) {
                    fx.drawScene(cv, f.img, srcR, dstR, blit, f.glow);
                    fx.drawOverlay(cv, dstR, f.glow);
                }
            }
            controls.draw(cv);
            drawError(cv);
            drawDebug(cv);
            drawStatus(cv);
            drawErrors = 0;
        } catch (RuntimeException e) {
            // desenho por GPU falhando varios quadros seguidos: cai para o desenho por CPU em vez de ficar sem imagem
            if (++drawErrors >= 5 && useHwCanvas) { useHwCanvas = false; android.util.Log.w("SOD", "canvas por hardware desligado: " + e); }
        } finally {
            if (cv != null) { try { h.unlockCanvasAndPost(cv); } catch (RuntimeException ignore) { } }
        }
        return true;
    }

    // ---- teclas (touch e teclado fisico) ----
    @Override public void key(int code, boolean down) {
        if (Net.role == Net.GUEST) { Net.sendKey(code, down); return; }
        Canvas c = Display.currentCanvas();
        if (c == null) return;
        // esta thread (interface) escreve nas teclas estaticas do jogo; o Hook troca essas teclas para mover o heroi 2.
        // A trava impede que as duas coisas aconteçam ao mesmo tempo (troca de controles entre jogador 1 e 2).
        synchronized (Hook.INPUT_LOCK) {
            if (down) c.__keyPressed(code); else c.__keyReleased(code);
        }
    }

    // ---- Net.Source ----
    @Override public byte[] grabJpeg() {
        Snap f = front;
        if (f == null) return null;
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(16384);
        // multiplayer: o convidado recebe o quadro em 240x320 (nao vale gastar rede com HD)
        Bitmap small = S == 1 ? f.img : Bitmap.createScaledBitmap(f.img, Display.WIDTH, Display.HEIGHT, true);
        boolean ok = small.compress(Bitmap.CompressFormat.JPEG, 70, bo);
        if (small != f.img) small.recycle();
        if (!ok) return null;
        return bo.toByteArray();
    }

    @Override public void refresh() { /* a thread de video ja redesenha sozinha a cada vsync */ }

    @Override public boolean onTouchEvent(MotionEvent ev) { return controls.onTouch(ev, this); }

    @Override public void surfaceCreated(SurfaceHolder holder) {
        ready = true;
        startDebugThread();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try { holder.getSurface().setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT); } catch (Throwable ignore) { }
        }
        stopRenderer();
        Renderer r = new Renderer();
        renderer = r;
        r.start();
    }

    @Override public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        controls.layout(w, h);   // a thread de video ja redesenha o ultimo quadro sozinha
    }

    @Override public void surfaceDestroyed(SurfaceHolder holder) {
        ready = false;
        stopRenderer();          // nao pode sobrar ninguem desenhando numa superficie destruida
    }

    private void stopRenderer() {
        Renderer r = renderer;
        renderer = null;
        if (r == null) return;
        r.running = false;
        r.interrupt();
        try { r.join(1000); } catch (InterruptedException ignore) { Thread.currentThread().interrupt(); }
    }
}
