package com.sod.port;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.util.LruCache;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.zip.CRC32;

/**
 * Remaster em alta resolucao.
 *
 * O jogo continua rodando em 240x320 (logica, colisao, posicoes). Cada imagem que ele carrega ganha
 * uma versao SCALE vezes maior, e o quadro final e desenhado em SCALE*240 x SCALE*320.
 * De onde vem a versao grande, em ordem:
 *   0) cache em memoria (LRU) - o jogo recria as mesmas imagens varias vezes (fases, paletas);
 *   1) um arquivo pronto  hd/<crc>.png  (pasta Android/data/com.sod.port/files/hd/ ou assets/hd/),
 *      feito por tools/upscale_hd.py (IA nos fundos, pixel art nos sprites);
 *   2) cache em disco (files/hdcache): ampliacao automatica ja feita numa execucao anterior;
 *   3) senao, ampliacao automatica na hora (Upscale: EPX nos sprites, bicubico nos fundos); o resultado
 *      e gravado no cache em disco por uma thread de segundo plano, entao so trava na 1a vez.
 * <crc> = CRC32 (8 hex) dos bytes exatos do PNG que o jogo entregou a Image.createImage.
 */
public final class HdPack {
    private HdPack() { }

    /** Fator de ampliacao (potencia de 2: 1 = original, 2, 4, 8). 4 -> quadro de 960x1280.
     *  Em aparelho fraco, 2 (480x640) deixa tudo bem mais leve. */
    public static final int SCALE = 4;
    /** Grava cada PNG que o jogo cria em files/dump/<crc>.png, para ampliar com tools/upscale_hd.py. */
    public static final boolean DUMP = true;
    /** Mude se o algoritmo de Upscale mudar: invalida o cache em disco antigo. */
    private static final int CACHE_VERSION = 1;

    private static final String TAG = "SOD";
    private static Context ctx;
    private static File hdDir, dumpDir, cacheDir;
    private static final HashSet<Long> dumped = new HashSet<Long>();
    /** Nomes (hd/<crc>.png) que existem de verdade no pacote do usuario: evita abrir arquivo/asset a toa. */
    private static final HashSet<String> userHd = new HashSet<String>();
    private static LruCache<Long, Bitmap> mem;
    private static ExecutorService io;

    public static void init(Context c) {
        ctx = c.getApplicationContext();
        File base = ctx.getExternalFilesDir(null);
        if (base == null) base = ctx.getFilesDir();
        hdDir = new File(base, "hd");
        dumpDir = new File(base, "dump");
        cacheDir = new File(ctx.getFilesDir(), "hdcache");
        if (DUMP) dumpDir.mkdirs();
        hdDir.mkdirs();
        cacheDir.mkdirs();

        long max = Runtime.getRuntime().maxMemory();
        int kb = (int) Math.min(96L * 1024, max / 1024 / 5);   // ate 96 MB, no maximo 1/5 do heap
        mem = new LruCache<Long, Bitmap>(Math.max(8 * 1024, kb)) {
            @Override protected int sizeOf(Long k, Bitmap b) { return b.getByteCount() / 1024; }
        };

        io = Executors.newSingleThreadExecutor(new ThreadFactory() {
            @Override public Thread newThread(final Runnable r) {
                Thread t = new Thread(new Runnable() {
                    @Override public void run() {
                        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); }
                        catch (Throwable ignore) { }
                        r.run();
                    }
                }, "hd-io");
                t.setDaemon(true);
                return t;
            }
        });

        synchronized (userHd) {
            userHd.clear();
            String[] f = hdDir.list();
            if (f != null) userHd.addAll(Arrays.asList(f));
            try {
                String[] as = ctx.getAssets().list("hd");
                if (as != null) userHd.addAll(Arrays.asList(as));
            } catch (java.io.IOException ignore) { }
        }
        Log.i(TAG, "HdPack: escala " + SCALE + "x, pasta " + base + ", pacote do usuario: " + userHd.size() + " imagens");
    }

    public static long crc(byte[] d, int off, int len) {
        CRC32 c = new CRC32();
        c.update(d, off, len);
        return c.getValue();
    }

    private static String name(long key) {
        String h = Long.toHexString(key);
        while (h.length() < 8) h = "0" + h;
        return h + ".png";
    }

    /** Grava o PNG original (uma vez por imagem; se o arquivo ja existe, nao regrava). Em segundo plano. */
    public static void dump(long key, byte[] d, int off, int len) {
        if (!DUMP || dumpDir == null || io == null) return;
        synchronized (dumped) { if (!dumped.add(key)) return; }
        final File f = new File(dumpDir, name(key));
        final byte[] copy = Arrays.copyOfRange(d, off, off + len);
        io.execute(new Runnable() {
            @Override public void run() {
                try {
                    if (f.exists()) return;
                    FileOutputStream o = new FileOutputStream(f);
                    try { o.write(copy); } finally { o.close(); }
                } catch (Throwable ignore) { }
            }
        });
    }

    /**
     * Versao grande da imagem de CRC 'key'. 'orig' e o bitmap original (usado so se precisar ampliar).
     * Devolve sempre um bitmap (ou lanca erro de memoria, que o Image trata).
     */
    public static Bitmap get(long key, Bitmap orig) {
        int w = orig.getWidth(), h = orig.getHeight();
        Bitmap b = mem.get(key);
        if (b != null) return b;
        b = lookup(key, w, h);
        if (b == null) b = readCache(key, w, h);
        if (b == null) {
            b = autoScale(orig);
            writeCache(key, b);
        }
        mem.put(key, b);
        return b;
    }

    /** Versao pronta (hd/<crc>.png); so vale se tiver exatamente SCALE x o tamanho original. */
    public static Bitmap lookup(long key, int w, int h) {
        if (ctx == null) return null;
        String n = name(key);
        synchronized (userHd) { if (!userHd.contains(n)) return null; }
        try {
            Bitmap b = null;
            File f = new File(hdDir, n);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            if (f.isFile()) {
                b = BitmapFactory.decodeFile(f.getPath(), o);
            } else {
                InputStream in = null;
                try { in = ctx.getAssets().open("hd/" + n); b = BitmapFactory.decodeStream(in, null, o); }
                catch (java.io.IOException noAsset) { b = null; }
                finally { if (in != null) { try { in.close(); } catch (java.io.IOException ignore) { } } }
            }
            if (b != null && b.getWidth() == w * SCALE && b.getHeight() == h * SCALE) return b;
            if (b != null) Log.w(TAG, "HdPack: " + n + " com tamanho errado, ignorado");
        } catch (Throwable t) {
            Log.w(TAG, "HdPack: falha lendo " + n + ": " + t);
        }
        return null;
    }

    private static File cacheFile(long key) {
        return new File(cacheDir, "v" + CACHE_VERSION + "_x" + SCALE + "_" + name(key));
    }

    private static Bitmap readCache(long key, int w, int h) {
        if (cacheDir == null) return null;
        File f = cacheFile(key);
        if (!f.isFile()) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
            if (b != null && b.getWidth() == w * SCALE && b.getHeight() == h * SCALE) return b;
            f.delete();   // corrompido ou de outro tamanho
        } catch (Throwable t) {
            Log.w(TAG, "HdPack: cache invalido " + f.getName() + ": " + t);
        }
        return null;
    }

    private static void writeCache(final long key, final Bitmap b) {
        if (cacheDir == null || io == null) return;
        io.execute(new Runnable() {
            @Override public void run() {
                File f = cacheFile(key);
                if (f.exists()) return;
                File tmp = new File(cacheDir, f.getName() + ".tmp");
                try {
                    FileOutputStream o = new FileOutputStream(tmp);
                    boolean ok;
                    try { ok = b.compress(Bitmap.CompressFormat.PNG, 100, o); } finally { o.close(); }
                    if (!ok || !tmp.renameTo(f)) tmp.delete();
                } catch (Throwable t) {
                    tmp.delete();
                }
            }
        });
    }

    /** Ampliacao automatica do bitmap original. */
    public static Bitmap autoScale(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] out = Upscale.auto(px, w, h, SCALE);
        return Bitmap.createBitmap(out, w * SCALE, h * SCALE, Bitmap.Config.ARGB_8888);
    }
}
