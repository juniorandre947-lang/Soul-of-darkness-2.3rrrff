package com.sod.port;
public final class SfxHook { public static void play(int id) { Trace.ev("SFX " + id); } }
