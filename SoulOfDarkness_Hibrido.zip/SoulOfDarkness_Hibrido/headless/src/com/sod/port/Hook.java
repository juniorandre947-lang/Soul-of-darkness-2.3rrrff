package com.sod.port;
import java.lang.reflect.*;
/** Hook de teste: sem multiplayer; apenas chama os metodos originais de e (ak/ao). */
public final class Hook {
    private static Method eAk, eAo;
    private static void init() throws Exception {
        if (eAk != null) return;
        Class<?> E = Class.forName("e");
        eAk = E.getDeclaredMethod("ak"); eAk.setAccessible(true);
        eAo = E.getDeclaredMethod("ao"); eAo.setAccessible(true);
    }
    private static void call(Method m) { try { m.invoke(null); } catch (InvocationTargetException ite) { Throwable c = ite.getCause(); if (c instanceof RuntimeException) throw (RuntimeException) c; if (c instanceof Error) throw (Error) c; throw new RuntimeException(c); } catch (IllegalAccessException e) { throw new RuntimeException(e); } }
    public static void ak() { try { init(); } catch (Exception e) { throw new RuntimeException(e); } call(eAk); }
    public static void ao() { try { init(); } catch (Exception e) { throw new RuntimeException(e); } call(eAo); }
    public static void pre(Object o) { }
    public static void post() { }
    public static void setHero(Object o) { }
}
