package com.sod.port;
/** Registro de eventos do harness: imprime "[tick] evento". */
public final class Trace {
    public static volatile long tick;
    public static volatile boolean on = true;
    public static final int[] COUNTS = new int[4096];
    public static void m(int id) { COUNTS[id]++; }
    public static final java.util.ArrayList<String> LOG = new java.util.ArrayList<String>();
    public static synchronized void ev(String s) { if (!on) return; String l = "[" + tick + "] " + s; LOG.add(l); if (LOG.size() < 100000) System.out.println(l); }
}
