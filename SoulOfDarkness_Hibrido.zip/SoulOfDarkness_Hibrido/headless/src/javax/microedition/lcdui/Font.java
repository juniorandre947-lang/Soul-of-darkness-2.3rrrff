package javax.microedition.lcdui;
public final class Font {
    public static final int FACE_SYSTEM = 0, FACE_MONOSPACE = 32, FACE_PROPORTIONAL = 64;
    public static final int STYLE_PLAIN = 0, STYLE_BOLD = 1, STYLE_ITALIC = 2, STYLE_UNDERLINED = 4;
    public static final int SIZE_MEDIUM = 0, SIZE_SMALL = 8, SIZE_LARGE = 16;
    private final int face, style, size;
    private static final Font DEFAULT = new Font(0, 0, 0);
    private Font(int f, int s, int z) { face = f; style = s; size = z; }
    public static Font getFont(int face, int style, int size) { return new Font(face, style, size); }
    public static Font getDefaultFont() { return DEFAULT; }
    private int px() { return size == 8 ? 10 : size == 16 ? 16 : 13; }
    public int getHeight() { return px() + 3; }
    public int getBaselinePosition() { return px(); }
    public int stringWidth(String s) { return s.length() * (px() * 6 / 10); }
    public int charWidth(char c) { return px() * 6 / 10; }
    public int getFace() { return face; } public int getStyle() { return style; } public int getSize() { return size; }
}
