package javax.microedition.lcdui;
/** Graphics sem tela (harness de testes): aceita tudo e nao desenha nada. */
public class Graphics implements com.nokia.mid.ui.DirectGraphics {
    public static final int HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64;
    public static final int SOLID = 0, DOTTED = 1;
    private Font font = Font.getDefaultFont();
    public Graphics() { }
    public void resetClip() { }
    public void setClip(int x, int y, int w, int h) { }
    public void setColor(int rgb) { }
    public void setColor(int r, int g, int b) { }
    public void setARGBColor(int argb) { }
    public void setFont(Font f) { font = f == null ? Font.getDefaultFont() : f; }
    public Font getFont() { return font; }
    public void fillRect(int x, int y, int w, int h) { }
    public void drawRect(int x, int y, int w, int h) { }
    public void drawLine(int a, int b, int c, int d) { }
    public void drawArc(int x, int y, int w, int h, int s, int a) { }
    public void fillArc(int x, int y, int w, int h, int s, int a) { }
    public void fillTriangle(int a, int b, int c, int d, int e, int f) { }
    public static final StringBuilder FRAME = new StringBuilder();
    public void drawString(String s, int x, int y, int anchor) { if (FRAME.length() < 600) FRAME.append(s).append(" | "); }
    public void drawImage(Image img, int x, int y, int anchor) { }
    public void drawRegion(Image img, int xs, int ys, int w, int h, int t, int xd, int yd, int anchor) { }
    public void drawRGB(int[] rgb, int offset, int scanlength, int x, int y, int w, int h, boolean processAlpha) { }
}
