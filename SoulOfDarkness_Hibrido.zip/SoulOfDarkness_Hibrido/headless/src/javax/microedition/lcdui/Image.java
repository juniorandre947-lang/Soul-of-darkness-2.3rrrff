package javax.microedition.lcdui;
import java.io.*;
public class Image {
    private final int w, h; private final int[] argb; private final boolean mutable;
    private Image(int w, int h, int[] px, boolean m) { this.w = Math.max(1, w); this.h = Math.max(1, h); this.argb = px != null ? px : new int[this.w * this.h]; mutable = m; }
    public static Image createImage(int w, int h) { return new Image(w, h, null, true); }
    public static Image createImage(String name) throws IOException {
        InputStream in = Image.class.getResourceAsStream(name);
        if (in == null) throw new IOException(name);
        byte[] d = in.readAllBytes(); in.close();
        return createImage(d, 0, d.length);
    }
    public static Image createImage(byte[] data, int off, int len) {
        try {
            java.awt.image.BufferedImage b = javax.imageio.ImageIO.read(new ByteArrayInputStream(data, off, len));
            if (b != null) {
                int[] px = new int[b.getWidth() * b.getHeight()];
                b.getRGB(0, 0, b.getWidth(), b.getHeight(), px, 0, b.getWidth());
                return new Image(b.getWidth(), b.getHeight(), px, false);
            }
        } catch (Throwable t) { }
        return new Image(8, 8, null, false);
    }
    public static Image createRGBImage(int[] rgb, int w, int h, boolean alpha) { return new Image(w, h, rgb.clone(), false); }
    public Graphics getGraphics() { return new Graphics(); }
    public int getWidth() { return w; } public int getHeight() { return h; } public boolean isMutable() { return mutable; }
    public void getRGB(int[] out, int offset, int scan, int x, int y, int ww, int hh) {
        for (int j = 0; j < hh; j++) for (int i = 0; i < ww; i++) {
            int sx = x + i, sy = y + j; int v = (sx >= 0 && sy >= 0 && sx < w && sy < h) ? argb[sy * w + sx] : 0;
            out[offset + j * scan + i] = v;
        }
    }
}
