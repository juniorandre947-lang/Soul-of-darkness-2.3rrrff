package javax.microedition.media;
import java.io.*;
/** Player de teste: nao toca nada, so registra (ver Trace). */
public class Manager {
    public static Player createPlayer(InputStream in, String type) throws IOException, MediaException {
        byte[] d = in.readAllBytes();
        final int len = d.length;
        com.sod.port.Trace.ev("MUSIC.create len=" + len + " type=" + type + " head=" + (len > 4 ? new String(d, 0, 4, "ISO-8859-1").replaceAll("[^ -~]", "?") : ""));
        return new Player() {
            int st = UNREALIZED;
            public void realize() { if (st < REALIZED) st = REALIZED; }
            public void prefetch() { realize(); st = PREFETCHED; }
            public void start() { st = STARTED; com.sod.port.Trace.ev("MUSIC.start"); }
            public void stop() { if (st == STARTED) st = PREFETCHED; com.sod.port.Trace.ev("MUSIC.stop"); }
            public void deallocate() { if (st > REALIZED) st = REALIZED; }
            public void close() { st = CLOSED; com.sod.port.Trace.ev("MUSIC.close"); }
            public int getState() { return st; }
            public void setLoopCount(int c) { }
        };
    }
}
