import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;
import com.sod.port.Trace;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Executa o jogo sem tela e injeta teclas por script.  Uso: java Run script.txt [rmsDir]
 *  Comandos: sleep MS | press CODE [MS] | down CODE | up CODE | mark TEXTO | quit */
public class Run {
    static volatile Canvas canvas; static String lastFrame = "";
    static java.lang.reflect.Field[] watch; static int[] prev; static int[] changes; static boolean watching = true;
    static void watchFields() {
        try {
            if (watch == null) {
                Class<?> E = Class.forName("e"); java.util.ArrayList<java.lang.reflect.Field> l = new java.util.ArrayList<java.lang.reflect.Field>();
                for (java.lang.reflect.Field f : E.getDeclaredFields()) if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) && (f.getType() == int.class || f.getType() == boolean.class || f.getType() == short.class || f.getType() == byte.class)) { f.setAccessible(true); l.add(f); }
                watch = l.toArray(new java.lang.reflect.Field[0]); prev = new int[watch.length]; changes = new int[watch.length];
                for (int i = 0; i < watch.length; i++) prev[i] = val(watch[i]);
                return;
            }
            for (int i = 0; i < watch.length; i++) {
                int v = val(watch[i]);
                if (v != prev[i]) { changes[i]++; if (changes[i] <= 12) Trace.ev("e." + watch[i].getName() + ": " + prev[i] + " -> " + v + (changes[i] == 12 ? "  (silenciado: muda demais)" : "")); prev[i] = v; }
            }
        } catch (Throwable t) { }
    }
    static int val(java.lang.reflect.Field f) { try { Object o = f.get(null); return o instanceof Boolean ? ((Boolean) o ? 1 : 0) : ((Number) o).intValue(); } catch (Throwable t) { return 0; } }
    public static void main(String[] args) throws Exception {
        File rms = new File(args.length > 1 ? args[1] : "/tmp/rms_sod"); rms.mkdirs();
        RecordStore.init(rms);
        final Graphics g = new Graphics();
        Display.host = new Display.Host() { public void repaint(Canvas c) { canvas = c; Trace.tick++; if (watching) watchFields(); Graphics.FRAME.setLength(0); try { c.__paint(g); } catch (Throwable t) { Trace.ev("PAINT-ERRO " + t); } String fs = Graphics.FRAME.toString(); if (!fs.equals(lastFrame)) { lastFrame = fs; Trace.ev("TELA: " + fs); } } };
        final Map<String, String> props = new HashMap<String, String>();
        props.put("MIDlet-Name", "Soul Of Darkness"); props.put("MIDlet-Version", "1.3.1"); props.put("MIDlet-Vendor", "Gameloft SA");
        MIDlet.host = new MIDlet.Host() {
            public void notifyDestroyed() { Trace.ev("notifyDestroyed"); }
            public String getAppProperty(String k) { return props.get(k); }
            public boolean platformRequest(String u) { return false; }
        };
        Thread t = new Thread(new Runnable() { public void run() {
            try { MIDlet m = (MIDlet) Class.forName("GloftSOFD").getDeclaredConstructor().newInstance(); m.__start(); }
            catch (Throwable e) { e.printStackTrace(); }
        } }, "midlet-start");
        t.start();
        List<String> script = Files.readAllLines(Paths.get(args[0]));
        for (String line : script) {
            line = line.trim(); if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split("\\s+", 2);
            String c = p[0], a = p.length > 1 ? p[1] : "";
            if (c.equals("sleep")) Thread.sleep(Long.parseLong(a));
            else if (c.equals("mark")) Trace.ev("=== " + a);
            else if (c.equals("quit")) break;
            else if (c.equals("calls")) {
                java.util.List<String> names = Files.readAllLines(Paths.get("methods.txt")); Integer[] idx = new Integer[Trace.COUNTS.length];
                for (int i = 0; i < idx.length; i++) idx[i] = i; final int[] cc = Trace.COUNTS;
                Arrays.sort(idx, new Comparator<Integer>() { public int compare(Integer x, Integer y) { return cc[y] - cc[x]; } });
                int top = a.isEmpty() ? 25 : Integer.parseInt(a); StringBuilder sb = new StringBuilder("CALLS (desde o ultimo reset):\n");
                for (int i = 0; i < top && cc[idx[i]] > 0; i++) sb.append("   ").append(cc[idx[i]]).append("x  ").append(idx[i] < names.size() ? names.get(idx[i]) : "?").append('\n');
                System.out.println(sb); Arrays.fill(Trace.COUNTS, 0);
            }
            else if (c.equals("dump")) {
                try {
                    Class<?> E = Class.forName("e"); StringBuilder sb = new StringBuilder("DUMP e: ");
                    for (java.lang.reflect.Field f : E.getDeclaredFields()) if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) { f.setAccessible(true); Object o = f.get(null);
                        if (o == null) continue; if (o instanceof Number || o instanceof Boolean) { if (o instanceof Number && ((Number) o).intValue() == 0) continue; if (Boolean.FALSE.equals(o)) continue; sb.append(f.getName()).append('=').append(o).append(' '); }
                        else if (o.getClass().getName().equals("b")) sb.append(f.getName()).append("=<b> ");
                        else if (o.getClass().isArray()) sb.append(f.getName()).append("=[").append(java.lang.reflect.Array.getLength(o)).append("] "); }
                    Trace.ev(sb.toString());
                    java.lang.reflect.Field bl = E.getDeclaredField("bL"); bl.setAccessible(true); Object h = bl.get(null);
                    if (h != null) { StringBuilder sh = new StringBuilder("DUMP heroi(bL): "); for (java.lang.reflect.Field f : h.getClass().getDeclaredFields()) if (!java.lang.reflect.Modifier.isStatic(f.getModifiers()) && (f.getType() == int.class || f.getType() == boolean.class || f.getType() == short.class)) { f.setAccessible(true); Object o = f.get(h); if (o instanceof Number && ((Number) o).intValue() == 0) continue; if (Boolean.FALSE.equals(o)) continue; sh.append(f.getName()).append('=').append(o).append(' '); } Trace.ev(sh.toString()); }
                    else Trace.ev("DUMP: e.bL == null (sem heroi)");
                } catch (Throwable tt) { Trace.ev("dump erro " + tt); }
            }
            else if (c.equals("press") || c.equals("down") || c.equals("up")) {
                String[] q = a.split("\\s+"); int code = Integer.parseInt(q[0]);
                Canvas cv = canvas; if (cv == null) { Trace.ev("(sem canvas ainda)"); continue; }
                if (!c.equals("up")) { Trace.ev("KEY down " + code); cv.__keyPressed(code); }
                if (c.equals("press")) { Thread.sleep(q.length > 1 ? Long.parseLong(q[1]) : 120); }
                if (!c.equals("down")) { cv.__keyReleased(code); Trace.ev("KEY up " + code); }
            }
        }
        System.out.println("fim do script; ticks=" + Trace.tick);
        System.exit(0);
    }
}
