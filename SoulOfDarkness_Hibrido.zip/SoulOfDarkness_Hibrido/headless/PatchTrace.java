import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import java.io.*; import java.util.*; import java.util.zip.*;
/** Insere Trace.m(id) na entrada de cada metodo de a,b,d,e (contagem de chamadas) e grava ids em methods.txt */
public class PatchTrace {
    public static void main(String[] a) throws Exception {
        ZipFile in = new ZipFile(a[0]); ZipOutputStream out = new ZipOutputStream(new FileOutputStream(a[1]));
        PrintWriter map = new PrintWriter(new FileWriter(a[2])); int id = 0;
        for (Enumeration<? extends ZipEntry> en = in.entries(); en.hasMoreElements();) {
            ZipEntry ze = en.nextElement(); byte[] data = in.getInputStream(ze).readAllBytes();
            String n = ze.getName();
            if (n.equals("a.class") || n.equals("b.class") || n.equals("d.class") || n.equals("e.class")) {
                ClassNode cn = new ClassNode(); new ClassReader(data).accept(cn, 0);
                for (MethodNode m : cn.methods) {
                    if (m.name.equals("<clinit>") || m.instructions.size() == 0 || (m.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) continue;
                    InsnList l = new InsnList(); l.add(new IntInsnNode(Opcodes.SIPUSH, id));
                    l.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/sod/port/Trace", "m", "(I)V", false));
                    // em construtores, inserir depois do super() e dificil; inserir no inicio e valido para chamadas estaticas simples (nao toca em 'this')
                    m.instructions.insert(l);
                    map.println(id + " " + cn.name + "." + m.name + m.desc); id++;
                }
                ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS); cn.accept(cw); data = cw.toByteArray();
            }
            ZipEntry ne = new ZipEntry(n); ne.setTime(ze.getTime()); out.putNextEntry(ne); out.write(data); out.closeEntry();
        }
        out.close(); map.close(); System.out.println("metodos instrumentados: " + id);
    }
}
