import json,glob,os
from PIL import Image
B='/home/claude/sod/SoD_DSi_extraido/'
TAB=json.load(open(B+'analise_arm9/tabela_recursos.json'))
def tex_img(tex,w,h):
    c=glob.glob(B+'imagens_sprites/%s_*x*.png'%tex)
    c=[f for f in c if os.path.basename(f).rsplit('_',1)[0]==tex]
    if not c: return None
    im=Image.open(c[0]).convert('RGBA'); W,H=im.size
    if W*H<w*h: return None
    if (W,H)==(w,h): return im
    px=list(im.getdata())[:w*h]
    n=Image.new('RGBA',(w,h)); n.putdata(px); return n
def images(name):
    return [tex_img(e['tex'],e['w'],e['h']) for e in TAB.get(name+'.bsprite',[])]
def render_frame(S,imgs,fi):
    n,start=S['frames[n_fmods,inicio]'][fi][:2]
    mods=S['modulos[img,x,y,w,h]']; fm=S['fmodulos[mod,ox,oy,flags]']
    parts=[];x0=y0=1e9;x1=y1=-1e9
    for k in range(start,start+n):
        m,ox,oy,fl=fm[k]
        if m>=len(mods): continue
        im,x,y,w,h=mods[m]
        parts.append((m,ox,oy,fl,im,x,y,w,h))
        x0=min(x0,ox);y0=min(y0,oy);x1=max(x1,ox+w);y1=max(y1,oy+h)
    if not parts: return None,(0,0)
    out=Image.new('RGBA',(x1-x0,y1-y0),(0,0,0,0))
    for m,ox,oy,fl,im,x,y,w,h in parts:
        if im>=len(imgs) or imgs[im] is None: continue
        c=imgs[im].crop((x,y,x+w,y+h))
        if fl&1: c=c.transpose(Image.FLIP_LEFT_RIGHT)
        if fl&2: c=c.transpose(Image.FLIP_TOP_BOTTOM)
        out.alpha_composite(c,(ox-x0,oy-y0))
    return out,(x0,y0)
