import json,os,sys,shutil
sys.path.insert(0,'/home/claude/sod')
from sprlib import *
O='/home/claude/sod/port/'
for d in('tex','spr','lvl'): os.makedirs(O+d,exist_ok=True)
tipo=json.load(open('/tmp/tipo_sprite.json'))
names={'hero_a'}|{v['sprite'] for v in tipo.values()}|{'effect_attack','effect_light','effect_thunder','item','interface'}
manifest={}
for n in sorted(names):
    p=B+'sprites_json/%s.json'%n
    if not os.path.exists(p): print('sem json',n); continue
    S=json.load(open(p)); ims=images(n); files=[]
    for i,im in enumerate(ims):
        if im is None: files.append(None); continue
        f='tex/%s_%d.png'%(n,i); im.save(O+f,optimize=True); files.append(f)
    out=dict(mods=S['modulos[img,x,y,w,h]'],fm=S['fmodulos[mod,ox,oy,flags]'],fr=S['frames[n_fmods,inicio]'],
             af=S['aframes[frame,tempo,b2,b3,b4]'],an=S['anims[n_aframes,inicio]'],tex=files)
    json.dump(out,open(O+'spr/%s.json'%n,'w'),separators=(',',':')); manifest[n]=len(out['an'])
print(manifest)
lv=[]
for i in range(1,11):
    m=json.load(open(B+'fases/fase_%02d_mapas.json'%i)); A=m['camadas']['A']
    ob=json.load(open(B+'fases/fase_%02d_objetos.json'%i))
    shutil.copy(B+'fases/fase_%02d_preview.png'%i,O+'lvl/%02d.png'%i)
    json.dump(dict(w=A['w'],h=A['h'],col=A['tiles'],obj=[[o['tipo'],o['id'],o['x'],o['y'],o['extra']] for o in ob]),
              open(O+'lvl/%02d.json'%i,'w'),separators=(',',':'))
    lv.append(i)
json.dump(dict(tipo={int(k):v['sprite'] for k,v in tipo.items()},levels=lv),open(O+'manifest.json','w'))
