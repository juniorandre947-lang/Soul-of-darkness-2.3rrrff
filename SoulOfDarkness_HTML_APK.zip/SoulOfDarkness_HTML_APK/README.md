# Soul of Darkness - port HTML5 para Android (WebView)

Motor HTML5 (`app/src/main/assets/www/`) empacotado num app Android que so abre um WebView.

## Gerar o APK pelo GitHub
1. Crie um repositorio **privado** e envie TODO o conteudo desta pasta (a pasta oculta `.github` precisa ir junto).
2. Aba **Actions > Build APK** roda a cada push (ou clique em *Run workflow*).
3. Ao terminar, baixe o artefato **SoulOfDarkness-debug-apk** (zip com `app-debug.apk`) e instale no celular.

## Gerar localmente
Android Studio: `File > Open` nesta pasta e `Build > Build APK(s)`. Ou `gradle assembleDebug` (Gradle 8.7, JDK 17).

## Estrutura
| Caminho | Funcao |
|---|---|
| `app/src/main/assets/www/` | o jogo: `index.html`, `manifest.json`, `lvl/`, `spr/`, `tex/` |
| `app/src/main/java/com/sod/webport/MainActivity.java` | WebView + servidor de assets em `https://appassets.local/` |
| `tools/export_port.py`, `tools/sprlib.py` | geram `www/` a partir do dump extraido (precisam da pasta `SoD_DSi_extraido`) |
| `.github/workflows/build.yml` | build do APK |

Controles: setas/AD, Z ou W = pular, X = atacar; botoes na tela no celular.
Pendente: gatilhos/portas/chefes (item 1 das fases), IA real, música original (os sons atuais são sintetizados e provisórios).
