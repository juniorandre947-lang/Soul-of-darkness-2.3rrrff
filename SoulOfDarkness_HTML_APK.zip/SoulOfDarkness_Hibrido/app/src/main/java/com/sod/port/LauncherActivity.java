package com.sod.port;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tela inicial do app: escolhe entre o jogo original completo (J2ME) e o port DSi (protótipo). */
public class LauncherActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(0xFF08050F);
        root.setPadding(40, 20, 40, 20);

        TextView title = new TextView(this);
        title.setText("SOUL OF DARKNESS");
        title.setTextColor(0xFFC8A0FF);
        title.setTextSize(30);
        title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        root.addView(button("Jogo completo (versão original)\nhistória, fases, diálogos, som, multiplayer", new Runnable() {
            @Override public void run() { startActivity(new Intent(LauncherActivity.this, MainActivity.class)); }
        }));
        root.addView(button("Versão DSi (protótipo)\ncenários do DSi, ainda em desenvolvimento", new Runnable() {
            @Override public void run() { startActivity(new Intent(LauncherActivity.this, DsiActivity.class)); }
        }));
        setContentView(root);
    }

    private Button button(String text, final Runnable r) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(16);
        bt.setTextColor(Color.WHITE);
        bt.setBackgroundColor(0xFF2A2347);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 24;
        lp.leftMargin = 60; lp.rightMargin = 60;
        bt.setLayoutParams(lp);
        bt.setPadding(20, 24, 20, 24);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
        return bt;
    }
}
