package javax.microedition.media;

import android.media.MediaPlayer;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Player do MMAPI em cima de MediaPlayer (o audio vai para um arquivo temporario). */
final class AndroidPlayer implements Player, MediaPlayer.OnCompletionListener {
    private static int counter;
    private MediaPlayer mp;
    private File file;
    private int state = UNREALIZED;
    private int loops = 1, played;
    private boolean prepared;

    AndroidPlayer(InputStream in, String type) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        byte[] d = bo.toByteArray();
        File dir = Manager.cacheDir != null ? Manager.cacheDir : new File(System.getProperty("java.io.tmpdir", "."));
        synchronized (AndroidPlayer.class) { file = new File(dir, "snd" + (counter++) + ext(type, d)); }
        FileOutputStream fo = new FileOutputStream(file);
        try { fo.write(d); } finally { fo.close(); }
        file.deleteOnExit();
    }

    private static String ext(String type, byte[] d) {
        if (d.length > 4) {
            if (d[0] == 'M' && d[1] == 'T' && d[2] == 'h' && d[3] == 'd') return ".mid";
            if (d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F') return ".wav";
            if (d[0] == '#' && d[1] == '!' && d[2] == 'A' && d[3] == 'M') return ".amr";
            if (d[0] == 'I' && d[1] == 'D' && d[2] == '3') return ".mp3";
        }
        if (type != null) {
            String t = type.toLowerCase();
            if (t.contains("wav")) return ".wav";
            if (t.contains("amr")) return ".amr";
            if (t.contains("mpeg") || t.contains("mp3")) return ".mp3";
        }
        return ".mid";
    }

    public synchronized void realize() { if (state == UNREALIZED) state = REALIZED; }

    public synchronized void prefetch() throws MediaException {
        realize();
        if (state >= PREFETCHED) return;
        try {
            if (mp == null) {
                mp = new MediaPlayer();
                mp.setOnCompletionListener(this);
                mp.setDataSource(file.getPath());
            }
            if (!prepared) { mp.prepare(); prepared = true; }
            state = PREFETCHED;
        } catch (Exception e) {
            throw new MediaException(String.valueOf(e));
        }
    }

    public synchronized void start() throws MediaException {
        prefetch();
        try {
            played = 0;
            mp.setLooping(loops == -1);
            mp.start();
            state = STARTED;
        } catch (Exception e) {
            throw new MediaException(String.valueOf(e));
        }
    }

    public synchronized void stop() throws MediaException {
        if (mp != null && state == STARTED) {
            try { mp.pause(); } catch (Exception ignore) { }
            state = PREFETCHED;
        }
    }

    public synchronized void deallocate() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignore) { }
            try { mp.reset(); } catch (Exception ignore) { }
            try { mp.release(); } catch (Exception ignore) { }
            mp = null; prepared = false;
        }
        if (state > REALIZED) state = REALIZED;
    }

    public synchronized void close() {
        deallocate();
        state = CLOSED;
        if (file != null) { file.delete(); file = null; }
    }

    public synchronized int getState() { return state; }

    public synchronized void setLoopCount(int count) {
        loops = count;
        if (mp != null) { try { mp.setLooping(count == -1); } catch (Exception ignore) { } }
    }

    public synchronized void onCompletion(MediaPlayer m) {
        played++;
        if (loops > 1 && played < loops) {
            try { m.seekTo(0); m.start(); return; } catch (Exception ignore) { }
        }
        state = PREFETCHED;
    }
}
