package javax.microedition.media;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class Manager {
    static File cacheDir;
    public static void setCacheDir(File dir) { cacheDir = dir; }

    public static Player createPlayer(InputStream in, String type) throws IOException, MediaException {
        return new AndroidPlayer(in, type);
    }
}
